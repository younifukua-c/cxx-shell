# @cxx/ui

RepoDock 视觉与通用交互的 Vue 3 公共组件，不依赖 Electron、Git、应用外壳或项目模块。

```ts
import { CxxButton, CxxDialog, CxxDialogDrawer, uiStyles } from '@cxx/ui';
import '@cxx/ui/style.css';
```

壳外使用 `CxxThemeProvider` 统一选择皮肤与品牌色，原 `.cxx-theme` 仍默认深色。Shadow DOM 使用同源 uiStyles 字符串。Dialog 支持拖动/缩放/可选几何记忆；Drawer 支持调宽/铺满/收成可自定义的标签。

UI 组件的使用/API/交互示例见 `apps/docs` 文档站（根目录 `pnpm start`）。清单见 `docs/COMPONENT_LIBRARY.md`，应用接入见 `docs/INTEGRATION.md`。

按钮只有一颗：图标形态传 `icon-only`，图文形态在默认插槽写文字。`icon` 接收 URL 或 `ButtonIcon` 四态对象；`src` 与 `#icon` 插槽继续有效。标准用法（确认 / 关闭 / 关机 / 卡片角删除）收在 `buttonPresets` 里，给 `preset` 名字即可。

```vue
<CxxButton icon-only label="刷新列表" :icon="refreshIcon" :busy="loading" @click="refresh" />
<CxxButton :icon="refreshIcon" icon-position="end" :busy="loading" @click="refresh">
  刷新列表
</CxxButton>
```

`ButtonIcon` 为 `string | { default: string; hover?: string; active?: string; disabled?: string }`，省略的状态回退到 default。`#icon` 插槽提供 `{ state, src }`，可放自定义 SVG / Vue 图标。日常只设置 `size`，按钮与图标一起使用 `buttonSizes` 尺寸合同；Vue 与原生 `createButton({ size })` 读取同一份档位。CSS 尺寸变量仅作为高级皮肤覆盖，默认不配置。

浅色单色资产可显式添加 `class="cxx-icon-monochrome"`，在浅色皮肤下自动压暗，深色皮肤保持原色；自定义皮肤可覆盖 `--cxx-monochrome-icon-filter`。彩色文件类型、品牌标识和深色图标保持默认，不使用此类。单色内联 SVG 优先采用 `currentColor` 跟随主题。
