# SCC JavaScript/TypeScript SDK

多软件宿主可通过 `@cxx/scc-sdk/desktop` 的 `createSccAccountProvider` 接入标准登录、本人摘要、批量软件资格和可重试退出。窗口、文件配置和公共组件通过显式端口注入，SDK 不依赖 Electron 或 UI。接入边界见[桌面多软件接入](../../docs/桌面多软件接入.md)。

整批软件同步同时读取一次本人显示名称，不逐软件查询。资料暂不可读时保留上次核验名称，使用资格仍取本次中央裁决；明确401或登录失效时清空身份。宿主按公开状态变化通知界面，稳定读取不触发新的同步循环。本人名称维护见[资料接口](../../docs/本人资料接口.md)。

`getRuntimeSoftwareAccess()` 的单项结果可带 `subscription: { planName, startsAt, expiresAt }`，仅为本人、客户端已绑定且本次请求软件的展示资料。优先显示当前覆盖周期，没有覆盖时显示最近订阅记录的周期，包含已过期或尚未开始的周期；套餐名为当前名称。它不改变 `allowed/reason/validUntil`，后者仍独立决定使用资格。桌面 `snapshot().software` 对应提供 `planName/startsAt/expiresAt`；退出后清除。旧服务缺少摘要时不猜日期，尤其不能把 `validUntil` 当购买到期日；此能力不开放桌面客户端枚举 `/me/applications`。

已登录时对全部目标软件统一查询中央裁决，包含管理员可开发的未上架、尚未录入软件。受信桌面连接可显式设置 `requestDevelopmentAccess: true` 请求 `admin.read`；通用连接默认不请求管理scope。管理员开发资格必须由中央验证真实管理员、客户端和会话，回执最多有效30秒，不受套餐到期限制，不创建软件或价格、不伪造收费模式，也不改变高风险管理操作的MFA要求。

JSON写请求在调用时、获取令牌之前固定正文；之后修改宿主对象不会改变本次下单或试用，首次发送与重试复用同一正文和幂等键。SDK不冻结或修改宿主对象；无法序列化的请求在获取令牌和联网之前拒绝。实际金额、可购买状态和使用资格仍由中心决定。

429/502/503/504的自动重试最多由`maxRetries`控制（0–3）。`Retry-After`只自动接受单个、至多64字符、0–5秒的非负整秒值，缺省一秒；过长、异常、重复值或HTTP日期均保留原接口错误，不猜等待时间。重试使用相同请求正文和幂等键，停止重试不表示购买未生效；应查询原订单，不能换键重付。

功能级中央判定使用 `await client.getFeatureAccess(productCode, featureCode)`，返回 `productCode/featureCode/allowed/reason/evaluatedAt/validUntil`。每次请求中心并核对目标，按当前覆盖周期的套餐版本判断，不提前采用未来续费版本；`FEATURE_NOT_INCLUDED` 表示未包含该功能。异常或拒绝均应阻止受保护的服务端动作，不能缓存旧放行结果；此查询不扣减配额，也不是离线许可。

本人积分需要客户端单独登记并由用户授权 `points.read`；`api.read` 不隐含该权限，机器令牌不可调用。

```javascript
const balance = await client.getPointBalance();
const first = await client.getPointLedger({ limit: 20 });
const next = first.nextCursor === null ? null
  : await client.getPointLedger({ limit: 20, cursor: first.nextCursor });
// 积分数量、变化量和版本保留字符串；需要精确计算时用BigInt，不用Number。
```

SDK只读取中心余额和不可变流水，不开户、不发放或本地扣分；返回对象只读，权限失败不回退旧余额。完整响应限制96KiB，禁止重定向且使用no-store。未配置方案返回404，未开户返回零余额和空流水；不把读取结果当作离线消费授权。

更新检查通过 `jose` 验证 RS256 签名，必须提供软件可信发布渠道预置的指纹：

```javascript
import { createSoftwareUpdateVerifier } from "@cxx/scc-sdk";
const verifier = await createSoftwareUpdateVerifier({
  jwks: await client.getSoftwareUpdateKeys(),
  pinnedThumbprints: trustedUpdateKeyThumbprints // 不从本次网络响应生成
});
const update = await client.checkSoftwareUpdate({ productCode: "MY_APP", platformCode: "windows",
  architectureCode: "x64", installedSequenceNo: "0" }, verifier);
```

序号和长度始终为精确字符串；无更新返回null，验签失败抛出 `INVALID_SOFTWARE_UPDATE`，不能回退旧结果。需 USER `api.read`；元数据响应最多96KiB，完整读取受总时限约束且禁止跳转。浏览器使用打包器解析锁定的 `jose` 依赖；现有免打包登录示例未配置更新依赖映射。浏览器入口不提供普通文件系统落盘，见[更新协议](../../docs/软件发布与更新查询接口.md)。

Node宿主通过独立入口完成验签、中央授权、流式核验和安全落盘，不把Node文件系统引入浏览器包：

```javascript
import { prepareSoftwareUpdate } from "@cxx/scc-sdk/updates-node";
const prepared = await prepareSoftwareUpdate({ baseUrl, accessTokenProvider, query, verifier,
  directory: privateCacheDirectory, idempotencyKey: stableDownloadIntentKey,
  downloadTimeoutMs: 300000, signal: abortController.signal });
// null表示无更新；否则prepared.file是完整文件，由宿主提示用户，不自动安装。
```

需同一用户的 `api.read api.write`；回执必须匹配签名目标、长度和SHA-256。只在宿主提供的本机私有目录中新建随机子目录，忽略远端文件名，不覆盖旧文件；拒绝跳转、编码、半包和摘要不符。使用标准异步文件写入，按块处理，不缓存完整文件。二进制最长五分钟且受中央授权更早期限约束，不自动重试或续传；原意图重试保留幂等键。二进制响应若在取消或超时后才返回，SDK仍会取消其正文；自定义传输须正确实现 `signal` 和正文取消，不得继续后台下载。失败自动清理本次文件，`UPDATE_CLEANUP_FAILED` 需检查缓存目录；成功文件由宿主安装前复核及用完清理。POSIX要求缓存目录仅当前用户可访问；**Windows私有ACL须由宿主保证**，Node内置文件模式不能替代Windows ACL，禁止选择共享可写目录。不要把浏览器Token持久化或写入示例配置文件。

Windows宿主可单独接收核心维护者提供的 `WindowsUpdateCache.ps1`，不需要核心JAR或源码；当前已发布的rc.6候选不含此独立脚本。使用PowerShell 7.2+载入后创建目录，保存返回路径供Node宿主使用；每次准备更新前调用只读检查：

```powershell
. '.\WindowsUpdateCache.ps1'
$cacheDirectory = New-SccWindowsUpdateCache -ParentDirectory 'E:\'
Assert-SccWindowsUpdateCache -Directory $cacheDirectory
```

`E:\`只是本机示例，实际父目录也必须通过检查。脚本使用[Windows原生ACL创建接口](https://learn.microsoft.com/en-us/dotnet/api/system.io.filesystemaclextensions.create)在创建时限制权限，只允许当前Windows账号、SYSTEM和本机管理员；不修改既有目录，不自动修复宽松权限。检查拒绝共享可写祖先、链接/联接、网络盘及不私有的缓存。它采用保守白名单，不解析任意Allow/Deny组合，不抵御同账号恶意程序或管理员；权限检查是当前快照，不替代安装前摘要复核。[Node文件模式不提供Windows用户隔离](https://nodejs.org/api/fs.html#fschmodpath-mode-callback)，不能只设置`0600`就视为安全。宿主须负责部署目标目录及后续ACL变更管理。

`@cxx/scc-sdk/oidc` 提供官方 OIDC 验签与单用户内存会话；`@cxx/scc-sdk/browser` 提供默认受控弹窗，以及服务器预批准的第一方当前页表单模式，均保留严格回调、取消清理和标准退出双回执。第一方嵌入模式支持 `auth.restore(signal)`，利用服务器仍有效的 HttpOnly 会话重新执行静默 PKCE，不持久化 Token，也不接收密码；恢复失败应显示登录表单。SDK 不提供 UI，接入方使用自己的组件和皮肤。配套[独立浏览器消费示例](../../examples/javascript-browser/README.md)不需要中心源码。部署及第一方配置见[浏览器指南](../../docs/JS浏览器登录与退出接入.md)，验收状态见项目阶段清单。

新增 `quoteDiscount({productCode, planCode, priceCode, activityCode})`，checkout 可传 activityCode 与 discountRevisionNo。金额始终保留字符串，不在 SDK 计算优惠；409 不静默调价。免付结果的 paymentNo、paymentStatus、actionValue 为 null，orderPaymentStatus 为 NOT_REQUIRED、actionType 为 NONE。完整交互及验证见 [优惠购买](../../docs/折扣购买与零元履约.md)。

套餐升级使用 `quoteUpgrade({productCode, targetPlanCode, targetPriceCode})`，用户明确确认后再调用 `upgradeCheckout(request, stableKey)`。请求带报价的 `sourcePeriodNo/subscriptionVersion/policy.version`（最后一项改名 `policyVersion`）、用户同意的 `maximumPayable` 和 `paymentChannel`；金额、版本必须保持字符串。SDK 不计价、不自动确认、不重试409；失败可能已经建单，必须保留原键与完整请求，不改键重付。完整契约见 [套餐升级接入](../../docs/软件接入与SDK指南.md#套餐升级先展示报价再确认下单)。

原支付操作提供 `await client.cancelUpgradePayment(paymentNo)`（仅未付款升级）和 `await client.reconcilePayment(paymentNo)`（购买或升级主动查单）。两者需要用户 `api.write` 及软件写授权，始终复用原支付编号，无额外幂等键。只有取消回执 `cancellationStatus=CANCELLED` 才能按取消展示；查单的关闭/未找到不证明取消或退款，中心 `paymentStatus=SUCCEEDED` 不因较早的等待观察回退，软件资格仍需向中心查询。未知结果不换单重付，SDK不持有商户密钥、不自动轮询或发起退款。

适用于浏览器、Node.js 服务端和桌面 Web 技术栈。浏览器/桌面属于 public client，只使用 Authorization Code + PKCE，不允许内置 `client_secret`。

中心 V10 已将用户授权绑定实际浏览器登录。宿主使用标准 OIDC 退出组件后，该次中心登录下的授权失效；只清空本机 Token 不等于中心退出。V11 管理员启停用户或撤销全部登录后，旧凭据不因重新启用而恢复，宿主应要求重新登录，不能回退本地允许结果。业务客户端不持有管理权限，也不自行刷新；可将独立 SccOidcSession 的 accessToken() 接为凭据提供者。AUTH-09 的服务端公共刷新须由管理员显式开启，完整宿主集成仍待 SDK-06，不应自行收集中心密码来绕过登录。

```js
import { SccBrowserOidc } from "@cxx/scc-sdk/browser";

const authentication = await SccBrowserOidc.discover({
  issuer: "https://auth.example.com",
  clientId: "product-a-web",
  redirectUri: "https://product-a.example.com/oauth/callback",
  postLogoutRedirectUri: "https://product-a.example.com/oauth/logout-callback",
  scope: "openid profile api.read api.write"
});
// 在真实点击事件中直接调用，并处理 Promise 错误；不要整页跳转销毁宿主。
// await authentication.login();
// 业务客户端：accessTokenProvider: () => authentication.accessToken()
```

Token 由宿主的安全存储/刷新组件提供给 `accessTokenProvider`。SDK 不把 Token 写入 `localStorage`，也不复制价格、订阅或权益状态机。

中心 V6 起按 Token 中的 `client_id` 实时校验软件绑定：查询需 READ_ONLY/READ_WRITE，购买、试用和兑换需 READ_WRITE，scope 仍独立校验。未绑定或只读写入返回 403；SDK 不自动重试，不通过自报 clientId 覆盖身份。管理配置与 MFA 由中心负责，产品不收集管理员密码。旧版本授权失效返回 401，不允许刷新绕过撤销。AUTH-09 服务端支持显式公共刷新和历史凭据撤销；新增 OIDC 入口在刷新响应未知时只撤销原家族，不重复刷新。平台安全存储与完整跨端接入仍未完成，详见 [公共刷新接入与限制](../../docs/公共客户端刷新与失败恢复.md)。

```js
const client = new SccClient({
  baseUrl: "https://auth.example.com",
  accessTokenProvider: () => tokenStore.currentAccessToken()
});

const methods = await client.getPaymentMethods("PRODUCT_A");
// 示例选择；实际界面让用户从 methods.channels 中选择。
const selectedChannel = "SANDBOX";
if (!methods.channels.includes(selectedChannel)) {
  throw new Error("当前软件未开放该支付方式");
}
const key = SccClient.newIdempotencyKey();
const checkout = await client.checkout({
  productCode: "PRODUCT_A",
  planCode: "PRO",
  priceCode: "PRO_MONTH_CNY_V1",
  paymentChannel: selectedChannel
}, key);
```

登录前可用 `new SccClient({ baseUrl })` 调用 `getOffer` 展示公开价格；已有令牌提供者也不会被报价调用。公开报价不带 Bearer/Cookie、不使用浏览器缓存或引用来源，不自动重试；完整响应受配置超时和 256 KiB 上限约束。报价不代表购买成功或功能权限；下单、试用、本人订阅及资格查询仍须提供 `accessTokenProvider`，缺少时在本地拒绝，不发送 HTTP 请求。Node 更新下载的令牌提供者仍为必填。

同一个客户端还提供：

```js
const offer = await client.getOffer({ productCode, planCode, priceCode });
const trial = await client.startTrial({ productCode, planCode, priceCode }, SccClient.newIdempotencyKey());
const redeemed = await client.redeem(userEnteredCode, SccClient.newIdempotencyKey());
const subscription = await client.getSubscription(redeemed.subscriptionNo);
const order = await client.getOrder(checkout.orderNo);
const access = await client.getProductAccess(productCode);
```

`getOrder(orderNo)` 只读取本人原订单，不重新下单或查询支付渠道。成交金额为精确字符串，返回快照及金额对象均冻结；错误时不沿用旧结果。`PAID` 或履约成功不能代替当前 `getProductAccess` 授权，`expiresAt` 是支付等待期限而非软件使用期限。

V14 起中心默认拒绝未配置的软件支付方式。运营人员需先通过管理 API 明确启用，发布价格和客户端绑定不能替代该配置。`getPaymentMethods` 使用最终用户 Token 和软件读授权；空列表表示当前没有开放渠道，不自动回退 `SANDBOX`。SDK 每次访问中心，检查响应软件一致、渠道格式和重复值，返回冻结对象/数组，不在错误时使用旧列表。结账仍重新检查配置；旧支付不因停用而撤销，超时继续使用原购买键确认，见 [软件支付方式管理](../../docs/软件支付方式管理.md)。V15 增加沙箱加密配置与原支付版本绑定，SDK 不持有渠道密钥，支付动作按原响应使用；全局停用会从列表排除渠道。真实商户收款仍未交付，见 [支付渠道配置与换钥](../../docs/支付渠道配置与换钥.md)。

`access.allowed === true` 才表示本次中央判定允许使用。判定包含当前身份、账户和实际生效周期；不能缓存为长期许可，超时或异常不得沿用旧的允许结果。受保护的服务端业务必须在服务端执行授权控制。完整边界见 [`外部接入与中央控权边界`](../../docs/外部接入与中央控权边界.md)。

远程 `baseUrl` 和 OAuth issuer 强制 HTTPS；只允许本机回环地址在联调时使用 HTTP，新 OIDC 入口还须显式 allowLoopbackHttp。写请求超时代表结果未知，重试必须复用同一幂等键。SccClient 只对 429/502/503/504 响应自动有限重试；独立 OIDC 入口负责单次刷新和 ID Token 校验，两者均不持久化 Token。不要把内存会话接到会销毁宿主的整页跳转流程。

业务请求的令牌等待与完整响应读取都有时限和体积限制，自定义 Fetch 忽略中止也不能延长 SDK 等待。传输异常统一为不含秘密的 `SDK_REQUEST_FAILED`，不自动重试、不回退缓存；它不是中心返回的502。超时配置、响应上限及原意图恢复规则见 [接入指南](../../docs/软件接入与SDK指南.md#5-幂等和重试)。

只读联调诊断：

```shell
npx scc-diagnose https://auth.example.com
```

完整安全流程、错误码与重试语义见 [`docs/软件接入与SDK指南.md`](../../docs/软件接入与SDK指南.md)，HTTP 类型契约见 [`docs/openapi-v1.yaml`](../../docs/openapi-v1.yaml)。
