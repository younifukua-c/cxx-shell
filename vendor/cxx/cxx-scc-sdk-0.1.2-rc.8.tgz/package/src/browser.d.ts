import type { SccOidcOptions } from "./oidc.js";

/** 浏览器公开客户端配置；两个回调必须与宿主页同源且路径不同。 */
export interface SccBrowserOidcOptions extends SccOidcOptions {
  /** 默认 popup；embedded 仅限由服务器预批准的同源第一方官网或显式固定同源反代。 */
  loginMode?: 'popup' | 'embedded';
  /** 显式使用官网同源反代送达授权/退出；issuer 与令牌验签不变，默认 false。 */
  embeddedProxy?: boolean;
  /** 必填的固定退出回调，必须通过中心管理 API 登记。 */
  postLogoutRedirectUri: string;
  /** 单次用户交互最大毫秒数，100–600000，默认 120000；包含回调后的认证处理。 */
  interactionTimeoutMs?: number;
}

/** 回调页静态配置，不得由 query、referrer 或消息提供。 */
export interface SccBrowserCallbackOptions {
  /** 固定部署模式，默认 popup；禁止从 query 或消息猜测。 */
  transport?: 'popup' | 'embedded';
  /** 当前回调页的精确登记地址，无 query/fragment。 */
  redirectUri: string;
  /** 固定宿主来源，仅 scheme/host/port，不带末尾斜杠；必须与回调同源。 */
  openerOrigin: string;
  /** 当前页面接收登录还是退出响应，不允许动态猜测。 */
  kind: "login" | "logout";
  /** 显式允许数值回环 HTTP，仅供本机联调。 */
  allowLoopbackHttp?: boolean;
}

/** 在专用回调页最先执行，清除敏感地址后向固定父页转交；返回不代表认证成功。 */
export declare function completeSccBrowserCallback(options: SccBrowserCallbackOptions,
  browserWindow?: Window): void;

/** 单用户、单宿主页、仅私有内存的认证接线；不适用于嵌入页或整页跳转恢复。 */
export declare class SccBrowserOidc {
  private constructor();
  /** 第一方页面通过现有Cookie会话及prompt=none恢复；无有效会话时拒绝，不读取本地凭据。 */
  restore(signal?: AbortSignal): Promise<Readonly<{subject:string;scope:string;expiresAt:number}>>;
  /** 点击前验证中心和固定回调；可注入可信窗口用于宿主适配/测试。 */
  static discover(options: SccBrowserOidcOptions, browserWindow?: Window): Promise<SccBrowserOidc>;
  /** 用户点击直接调用；严格接收弹窗回调并验证 OIDC，信号中止本次交互。 */
  login(signal?: AbortSignal): Promise<Readonly<{
    /** 经 OIDC 验证的用户主体，不是业务权益许可。 */
    subject: string;
    /** 中心实际授权的范围。 */
    scope: string;
    /** Access Token 本地保守到期时间，Unix 毫秒。 */
    expiresAt: number;
  }>>;
  /** 同源第一方直接表单登录；仍走 CSRF、浏览器会话、PKCE 与 OIDC，输入不可持久化或打印。 */
  loginEmbedded(username: string, password: string, signal?: AbortSignal): ReturnType<SccBrowserOidc['login']>;
  /** 仅用于业务 Authorization Header，禁止打印或持久化。 */
  accessToken(): Promise<string>;
  /** single-flight 刷新；失败时不自动重试，不能恢复已撤销身份。 */
  refresh(): Promise<string>;
  /** 用户点击直接调用；清本地、撤销家族、中心浏览器退出；失败后可再点击重试。 */
  logout(signal?: AbortSignal): Promise<Readonly<{
    /** 本次已知授权家族已收到中心撤销回执，不表示所有设备。 */
    revocationConfirmed: boolean;
    /** 本次中心浏览器退出已收到并验证精确 state 回调，不代替令牌撤销回执。 */
    browserLogoutConfirmed: boolean;
  }>>;
  /** 仅重试幂等撤销，不重用旧刷新凭据，不推定未知授权的处理结果。 */
  retryRevocation(): Promise<boolean>;
}
