/** 订单只读协议，金额保留十进制字符串，不在客户端推算授权或退款。 */
const MAX_AMOUNT = 9223372036854775807n;
const TYPES = new Set(["NEW", "RENEW", "CHANGE"]);
const ORDERS = new Set(["OPEN", "CLOSED", "CANCELLED", "EXPIRED"]);
const FUNDS = new Set(["UNPAID", "NOT_REQUIRED", "PAID", "PARTIALLY_REFUNDED", "REFUNDED"]);
const FULFILLMENT = new Set(["NOT_STARTED", "PROCESSING", "SUCCEEDED", "FAILED"]);

/** 拒绝协议错误，不携带报文、凭据或请求参数。 */
function invalid() { throw new TypeError("订单请求或中央响应无效"); }
/** 精确匹配完整文本，拒绝隐式转换及尾部换行。 */
function match(value, expression) {
  return typeof value === "string" && expression.test(value) ? value : invalid();
}
/** 在取得令牌及联网前验证订单公开编号。 */
export function orderNumber(value) {
  return match(value, /^[0-9A-HJKMNP-TV-Z]{26}(?![\s\S])/);
}
/** 校验金额并复制冻结，不允许不安全数值或外部对象修改快照。 */
function money(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  const amountMinor = match(value.amountMinor, /^(?:0|[1-9][0-9]{0,18})(?![\s\S])/);
  if (BigInt(amountMinor) > MAX_AMOUNT) invalid();
  return Object.freeze({ amountMinor, currency: match(value.currency, /^[A-Z]{3}(?![\s\S])/) });
}
/** 未知状态不降级成支付或开通成功。 */
function status(value, allowed) { return typeof value === "string" && allowed.has(value) ? value : invalid(); }

/** 核对订单目标与同币种成交金额；不将已收款等同已获得软件使用权限。 */
export function orderResult(value, requested) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  const orderNo = orderNumber(value.orderNo);
  if (orderNo !== requested) invalid();
  const original = money(value.original), payable = money(value.payable), discount = money(value.discount);
  if (original.currency !== payable.currency || original.currency !== discount.currency
      || BigInt(original.amountMinor) - BigInt(payable.amountMinor) !== BigInt(discount.amountMinor)) invalid();
  const discountRevisionNo = value.discountRevisionNo === null ? null : orderNumber(value.discountRevisionNo);
  const expiresAt = match(value.expiresAt, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z(?![\s\S])/);
  const timestamp = Date.parse(expiresAt);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 19) !== expiresAt.slice(0, 19)
      || !Number.isSafeInteger(value.version) || value.version < 0) invalid();
  return Object.freeze({ orderNo, orderType: status(value.orderType, TYPES), payable, original, discount,
    discountRevisionNo, orderStatus: status(value.orderStatus, ORDERS), paymentStatus: status(value.paymentStatus, FUNDS),
    fulfillmentStatus: status(value.fulfillmentStatus, FULFILLMENT), expiresAt, version: value.version });
}
