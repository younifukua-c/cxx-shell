/** 积分只读协议校验，不在SDK重算记账资格。 */
// 绝对结尾断言避免JavaScript的$接受末尾换行，整数和编号必须完全规范。
const PUBLIC_ID = /^[0-9A-HJKMNP-TV-Z]{26}(?![\s\S])/;
const INTEGER = /^(?:0|-?[1-9][0-9]{0,18})(?![\s\S])/;
const MAXIMUM = 9223372036854775807n;
const MINIMUM = -9223372036854775808n;
const TYPES = new Set(["EARN", "SPEND", "REFUND", "RECLAIM"]);

/** 拒绝错误协议而不把服务器原文放入异常。 */
function invalid() { throw new TypeError("中央积分响应无效"); }
/** 仅接受字符串，不进行有损数值转换。 */
function text(value) { return typeof value === "string" && value.trim() ? value : invalid(); }
/** 验证公开编号，可空字段必须明确为null。 */
function id(value, nullable = false) {
  return nullable && value === null ? null : PUBLIC_ID.test(text(value)) ? value : invalid();
}
/** 验证整数字符串的BIGINT范围并原样返回。 */
function integer(value, minimum = 0n) {
  if (typeof value !== "string" || !INTEGER.test(value)) invalid();
  const exact = BigInt(value);
  return exact >= minimum && exact <= MAXIMUM ? value : invalid();
}
/** 校验UTC时间字段，不推导业务有效期。 */
function time(value, nullable = false) {
  if (nullable && value === null) return null;
  return typeof value === "string" && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?Z(?![\s\S])/.test(value)
    && Number.isFinite(Date.parse(value)) ? value : invalid();
}
/** 校验页大小和公开游标，拒绝内部编号、超量和路径片段。 */
export function pointPageQuery(limit, cursor) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 100
      || (cursor != null && (typeof cursor !== "string" || !PUBLIC_ID.test(cursor)))) {
    throw new TypeError("积分页大小或游标无效");
  }
  return new URLSearchParams({ limit: String(limit), ...(cursor == null ? {} : { cursor }) });
}
/** 返回最小只读余额字段，不缓存或隐式创建钱包。 */
export function pointBalance(value) {
  if (!value || typeof value.enabled !== "boolean") invalid();
  return Object.freeze({ programNo: id(value.programNo), name: text(value.name), enabled: value.enabled,
    walletNo: id(value.walletNo, true), available: integer(value.available), frozen: integer(value.frozen),
    debt: integer(value.debt), version: integer(value.version, -1n), updatedAt: time(value.updatedAt, true) });
}
/** 返回有界不可变流水页，拒绝重复交易和不属于页尾的续页游标。 */
export function pointLedgerPage(value, limit) {
  if (!value || !Array.isArray(value.items) || value.items.length > limit) invalid();
  const seen = new Set();
  const items = value.items.map(row => {
    if (!row || !TYPES.has(row.type)) invalid();
    const transactionNo = id(row.transactionNo);
    if (seen.has(transactionNo)) invalid();
    seen.add(transactionNo);
    return Object.freeze({ transactionNo, type: row.type, amount: integer(row.amount, 1n),
      originalTransactionNo: id(row.originalTransactionNo, true), availableDelta: integer(row.availableDelta, MINIMUM),
      frozenDelta: integer(row.frozenDelta, MINIMUM), debtDelta: integer(row.debtDelta, MINIMUM),
      availableAfter: integer(row.availableAfter), frozenAfter: integer(row.frozenAfter), debtAfter: integer(row.debtAfter),
      occurredAt: time(row.occurredAt) });
  });
  const nextCursor = id(value.nextCursor, true);
  if (nextCursor !== null && (items.length !== limit || items.at(-1).transactionNo !== nextCursor)) invalid();
  return Object.freeze({ items: Object.freeze(items), nextCursor });
}
