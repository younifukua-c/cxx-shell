import { createHash, randomUUID } from "node:crypto";
import { lstat, realpath, mkdtemp, open, link, unlink, rmdir } from "node:fs/promises";
import { isAbsolute, normalize, dirname, join, parse } from "node:path";
import { SccClient } from "./client.js";
import { SccApiError } from "./errors.js";
import { abortable } from "./oidc-transport.js";
import { requireSoftwareUpdateVerifier, validateSoftwareDownloadGrant } from "./software-update.js";

const MAXIMUM_DOWNLOAD_MS = 5 * 60 * 1000;
const FILE_BUFFER_BYTES = 64 * 1024;

/** 宿主必须提供本机私有缓存目录；Windows权限由宿主配置，不能使用共享可写目录。 */
async function validateDirectory(directory) {
  if (typeof directory !== "string" || !isAbsolute(directory) || normalize(directory) !== directory
      || directory === parse(directory).root || directory.startsWith("\\\\")) throw new TypeError("需要本机可信缓存目录");
  for (let path = directory; ; path = dirname(path)) {
    const attributes = await lstat(path);
    if (!attributes.isDirectory() || attributes.isSymbolicLink()) throw new TypeError("缓存路径不能含链接");
    if (path === dirname(path)) break;
  }
  if (await realpath(directory) !== directory) throw new TypeError("需要真实缓存目录");
  if (process.platform !== "win32") {
    const attributes = await lstat(directory);
    if (attributes.uid !== process.getuid() || (attributes.mode & 0o077) !== 0) throw new TypeError("缓存目录必须仅允许当前用户访问");
  }
}

/** 无秘密正文和本地路径的统一下载失败。 */
function failure(code) {
  return new SccApiError({ status: 502, code, detail: "更新下载未完成，禁止安装；清理失败时请检查指定缓存目录" });
}

/**
 * Node宿主实时查询、验签、申请授权、流式核验并交付全新文件；不执行安装。
 * @param {object} options 中央客户端配置、query、verifier、directory、idempotencyKey、downloadTimeoutMs和可选signal。
 * @returns {Promise<object|null>} 已核验元数据与完整文件路径；无更新为null，宿主负责事后清理。
 */
export async function prepareSoftwareUpdate(options) {
  const { baseUrl, accessTokenProvider, fetchImpl = globalThis.fetch, timeoutMs = 10000, maxRetries = 2,
    verifier, directory, idempotencyKey, downloadTimeoutMs = MAXIMUM_DOWNLOAD_MS, signal } = options;
  const query = { ...options.query };
  if (typeof baseUrl !== "string") throw new TypeError("baseUrl必须是不可变地址字符串");
  requireSoftwareUpdateVerifier(verifier);
  if (!Number.isSafeInteger(downloadTimeoutMs) || downloadTimeoutMs < 1 || downloadTimeoutMs > MAXIMUM_DOWNLOAD_MS)
    throw new TypeError("下载时限必须为1至300000毫秒");
  if (typeof idempotencyKey !== "string" || !idempotencyKey.trim() || idempotencyKey.length > 128)
    throw new TypeError("下载授权需要稳定幂等键");
  await validateDirectory(directory);
  if (signal?.aborted) throw failure("UPDATE_DOWNLOAD_ABORTED");
  const client = new SccClient({ baseUrl, accessTokenProvider, fetchImpl, timeoutMs, maxRetries });
  const update = await client.checkSoftwareUpdate(query, verifier);
  if (signal?.aborted) throw failure("UPDATE_DOWNLOAD_ABORTED");
  if (update === null) return null;
  const grant = validateSoftwareDownloadGrant(await client.issueSoftwareDownloadGrant(query.productCode, update.target.targetNo, idempotencyKey), update);
  const expires = Date.parse(grant.expiresAt);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Math.max(1, Math.min(downloadTimeoutMs, expires - Date.now())));
  const onAbort = () => controller.abort();
  signal?.addEventListener("abort", onAbort, { once: true });
  if (signal?.aborted) controller.abort();
  let stage, reader, file;
  let partialOwned = false, linked = false, delivered = false;
  /** 授权或主动取消不能被后续正常EOF掩盖。 */
  function active() {
    if (controller.signal.aborted || Date.now() >= expires) throw failure("UPDATE_DOWNLOAD_ABORTED");
  }
  try {
    active();
    const token = await abortable(Promise.resolve().then(() => accessTokenProvider()), controller.signal);
    if (typeof token !== "string" || !token) throw failure("UPDATE_DOWNLOAD_FAILED");
    const base = new URL(baseUrl);
    const url = base.origin + base.pathname.replace(/\/+$/, "") + `/api/v1/products/${encodeURIComponent(query.productCode)}/software-downloads/${encodeURIComponent(grant.grantNo)}/content`;
    const pending = Promise.resolve().then(() => fetchImpl(url, {
      method: "GET", redirect: "manual", credentials: "omit", cache: "no-store", referrerPolicy: "no-referrer",
      headers: { Authorization: `Bearer ${token}`, Accept: "application/octet-stream", "Accept-Encoding": "identity", "X-Request-Id": randomUUID() },
      signal: controller.signal
    })).then(response => {
      // 自定义传输可能忽略取消；迟到正文仍归本次调用所有，不能遗留后台连接。
      if (controller.signal.aborted || Date.now() >= expires) {
        response.body?.cancel().catch(() => {});
        throw failure("UPDATE_DOWNLOAD_ABORTED");
      }
      return response;
    });
    const response = await abortable(pending, controller.signal);
    reader = response.body?.getReader();
    if (response.status !== 200 || response.redirected || (response.url && response.url !== url)
        || response.headers.get("content-length") !== update.target.byteLength
        || response.headers.get("content-type") !== "application/octet-stream"
        || response.headers.has("content-encoding") || response.headers.has("transfer-encoding") || !reader)
      throw failure("UPDATE_DOWNLOAD_FAILED");
    active();
    await validateDirectory(directory);
    stage = await mkdtemp(join(directory, ".scc-update-"));
    file = await open(join(stage, "payload.part"), "wx", 0o600);
    partialOwned = true;
    const digest = createHash("sha256");
    const expected = Number(update.target.byteLength);
    let received = 0;
    /** 标准writeFile消费异步迭代器并处理部分写入；不缓存完整文件。 */
    async function* chunks() {
      while (true) {
        active();
        const { done, value } = await abortable(reader.read(), controller.signal);
        if (done) break;
        active();
        if (!(value instanceof Uint8Array) || value.byteLength > expected - received) throw failure("UPDATE_DOWNLOAD_FAILED");
        received += value.byteLength;
        digest.update(value);
        for (let offset = 0; offset < value.byteLength; offset += FILE_BUFFER_BYTES) {
          active();
          yield value.subarray(offset, offset + FILE_BUFFER_BYTES);
        }
      }
      active();
      if (received !== expected || digest.digest("hex") !== update.target.sha256) throw failure("UPDATE_DOWNLOAD_FAILED");
    }
    await file.writeFile(chunks(), { signal: controller.signal });
    await file.sync();
    await file.close();
    file = undefined;
    active();
    const complete = join(stage, "payload.bin");
    await link(join(stage, "payload.part"), complete);
    linked = true;
    await unlink(join(stage, "payload.part"));
    partialOwned = false;
    active();
    delivered = true;
    return Object.freeze({ update, file: complete });
  } catch (error) {
    if (error instanceof SccApiError) throw error;
    throw failure(controller.signal.aborted ? "UPDATE_DOWNLOAD_ABORTED" : "UPDATE_DOWNLOAD_FAILED");
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
    controller.abort();
    reader?.cancel().catch(() => {});
    try {
      if (file) await file.close();
      if (!delivered && stage) {
        if (partialOwned) await unlink(join(stage, "payload.part"));
        if (linked) await unlink(join(stage, "payload.bin"));
        await rmdir(stage);
      }
    } catch { throw failure("UPDATE_CLEANUP_FAILED"); }
  }
}
