import * as oauth from "oauth4webapi";
import { boundedOidcFetch, secureUrl } from "./oidc-transport.js";

/** 浏览器授权事务最长保留十分钟，不是服务端授权码有效期。 */
const LOGIN_TTL_MS = 10 * 60 * 1000;
/** 提前刷新窗口，避免在业务请求途中使用即将过期的令牌。 */
const REFRESH_LEEWAY_MS = 30 * 1000;
/** 中心用户访问令牌最长十分钟；允许服务端缩短，不接受扩大。 */
const MAX_ACCESS_LIFETIME_SECONDS = 600;
/** Spring Authorization Server 的 ID Token 默认寿命，与 Access Token 分开校验。 */
const MAX_ID_LIFETIME_SECONDS = 30 * 60;
/** 回调和凭据长度限制，避免异常响应成为无界内存或日志数据。 */
const MAX_CALLBACK_LENGTH = 16384;
const MAX_TOKEN_LENGTH = 8192;
/** 阻止 JavaScript 宿主跳过 discover 直接注入未验证元数据。 */
const VERIFIED_CONFIGURATION = Symbol();
/** 授权码流程允许的标准 query 参数；禁止隐式令牌回调。 */
const CALLBACK_PARAMETERS = new Set([
  "code", "state", "iss", "error", "error_description", "error_uri", "scope"
]);

/** 不携带底层异常 cause、原始响应或凭据的稳定认证错误。 */
export class SccOidcError extends Error {
  /**
   * @param {string} code 固定错误码；调用方按码决定重新授权或重试撤销。
   * @param {boolean} revocationConfirmed 是否收到中心对本次已知凭据撤销的成功回执。
   */
  constructor(code, revocationConfirmed = false) {
    super(code);
    this.name = "SccOidcError";
    this.code = code;
    this.revocationConfirmed = revocationConfirmed;
  }
}

/**
 * 解析严格、不重复的 OAuth scope；不在客户端扩张中心授权范围。
 * @param {string} scope 请求或响应的空格分隔范围。
 * @returns {string[]} 不重复的范围名称。
 */
function scopes(scope) {
  if (typeof scope !== "string" || scope.length > 2048
      || !/^[\x21\x23-\x5B\x5D-\x7E]+(?: [\x21\x23-\x5B\x5D-\x7E]+)*$/.test(scope)) {
    throw new Error("OIDC_SCOPE_INVALID");
  }
  const values = scope.split(" ");
  if (new Set(values).size !== values.length || !values.includes("openid")) {
    throw new Error("OIDC_SCOPE_INVALID");
  }
  return values;
}

/**
 * 仅接受有界、可放入标准表单或 Authorization Header 的不透明凭据。
 * @param {unknown} value 原始凭据。
 * @returns {boolean} 凭据结构是否可用；不代表签名或中央状态已验证。
 */
function tokenShape(value) {
  return typeof value === "string" && value.length <= MAX_TOKEN_LENGTH
    && /^[\x21-\x7E]+$/.test(value);
}

/**
 * 创建公开客户端的独立 OIDC 会话；所有凭据只保存在对象私有内存。
 * 一个对象只属于一个用户和一个登录流程，禁止在多用户 BFF 中全局共享。
 */
export class SccOidcSession {
  /** 已验证、固定的发现元数据，不对宿主暴露可变引用。 */
  #server;
  /** 无 client_secret 的公开客户端元数据，算法固定 RS256。 */
  #client;
  /** 精确登记的授权回调地址。 */
  #redirectUri;
  /** 精确登记的浏览器退出回调地址，未配置时只进行令牌撤销。 */
  #postLogoutRedirectUri;
  /** 此软件登录需要的最小权限集合。 */
  #scope;
  /** 受限传输和 JWKS 校验选项。 */
  #options;
  /** 待消费的内存授权事务，不对外输出 PKCE verifier。 */
  #login;
  /** 待验证的浏览器退出回调事务。 */
  #logout;
  /** 仅供浏览器退出的身份提示，不能再次用于认证、刷新或业务调用。 */
  #logoutHint;
  /** 当前唯一可用令牌集合；不复制中心用户、套餐或权益事实。 */
  #tokens;
  /** 登录世代；退出和失败使旧异步响应失效。 */
  #generation = 0;
  /** 同一会话的共享刷新任务。 */
  #refresh;
  /** 尚未结束的换码或刷新数量；恢复新登录前必须全部落定。 */
  #exchanges = 0;
  /** 尚未确认撤销的已知凭据；仅允许重试撤销，不再用于刷新或业务。 */
  #recoveryToken;
  /** 同一已知凭据的共享撤销任务。 */
  #revocation;
  /** 曾出现无可用凭据的未知换码结果，必须通过中心会话管理核实。 */
  #unknownAuthorization = false;

  /**
   * 加载并核验固定 issuer 的发现文档；调用方不得从回调参数决定 issuer。
   * @param {import('./oidc.js').SccOidcOptions} configuration 部署时配置的公开客户端参数。
   * @returns {Promise<SccOidcSession>} 尚未登录的独立会话。
   */
  static async discover(configuration) {
    try {
      const { issuer, clientId, redirectUri, scope,
        postLogoutRedirectUri, allowLoopbackHttp = false,
        timeoutMs = 10000, fetchImpl = globalThis.fetch } = configuration;
      const issuerUrl = secureUrl(issuer, allowLoopbackHttp);
      if (issuerUrl.pathname !== "/" || typeof clientId !== "string"
          || !/^[\x21-\x7E]{1,200}$/.test(clientId)
          || !Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 30000
          || typeof fetchImpl !== "function") throw new Error("OIDC_CONFIG_INVALID");
      const redirect = secureUrl(redirectUri, allowLoopbackHttp).href;
      const postLogout = postLogoutRedirectUri === undefined ? undefined
        : secureUrl(postLogoutRedirectUri, allowLoopbackHttp).href;
      const requested = scopes(scope).join(" ");
      const options = {
        [oauth.customFetch]: boundedOidcFetch(issuerUrl, fetchImpl, timeoutMs),
        [oauth.allowInsecureRequests]: issuerUrl.protocol === "http:"
      };
      const response = await oauth.discoveryRequest(issuerUrl, options);
      const server = await oauth.processDiscoveryResponse(issuerUrl, response);
      if (server.issuer !== issuer
          || !server.code_challenge_methods_supported?.includes("S256")
          || !server.id_token_signing_alg_values_supported?.includes("RS256")
          || !server.response_types_supported?.includes("code")
          || !server.token_endpoint_auth_methods_supported?.includes("none")) {
        throw new Error("OIDC_METADATA_INVALID");
      }
      for (const name of ["authorization_endpoint", "token_endpoint", "jwks_uri",
        "revocation_endpoint", ...(postLogout ? ["end_session_endpoint"] : [])]) {
        if (secureUrl(server[name], allowLoopbackHttp).origin !== issuerUrl.origin) {
          throw new Error("OIDC_ENDPOINT_REJECTED");
        }
      }
      return new SccOidcSession(VERIFIED_CONFIGURATION,
        { server, clientId, redirect, postLogout, requested, options });
    } catch {
      throw new SccOidcError("OIDC_CONFIGURATION_REJECTED");
    }
  }

  /** 内部构造；宿主必须通过 discover 完成元数据验证。 */
  constructor(verified, configuration) {
    if (verified !== VERIFIED_CONFIGURATION) throw new SccOidcError("OIDC_CONFIGURATION_REJECTED");
    const { server, clientId, redirect, postLogout, requested, options } = configuration;
    this.#server = server;
    this.#client = { client_id: clientId, id_token_signed_response_alg: "RS256",
      [oauth.clockTolerance]: 0 };
    this.#redirectUri = redirect;
    this.#postLogoutRedirectUri = postLogout;
    this.#scope = requested;
    this.#options = options;
  }

  /**
   * 生成一次性授权地址；由仍存活的宿主通过系统浏览器或受控弹窗完成跳转。
   * @returns {Promise<string>} 含 state/nonce/PKCE challenge 的授权地址；禁止写入日志。
   */
  async beginLogin(options = {}) {
    if (options.prompt !== undefined && options.prompt !== 'none') throw new SccOidcError('OIDC_CONFIGURATION_REJECTED');
    if (this.#tokens || this.#login || this.#exchanges || this.#recoveryToken) {
      throw new SccOidcError("OIDC_SESSION_BUSY");
    }
    const transaction = { state: oauth.generateRandomState(), nonce: oauth.generateRandomNonce(),
      verifier: oauth.generateRandomCodeVerifier(), createdAt: Date.now(),
      generation: ++this.#generation };
    this.#login = transaction;
    this.#logout = undefined;
    this.#logoutHint = undefined;
    try {
      const challenge = await oauth.calculatePKCECodeChallenge(transaction.verifier);
      if (this.#login !== transaction) throw new Error("OIDC_LOGIN_CANCELLED");
      const url = new URL(this.#server.authorization_endpoint);
      url.search = new URLSearchParams({ client_id: this.#client.client_id,
        response_type: "code", redirect_uri: this.#redirectUri, scope: this.#scope,
        state: transaction.state, nonce: transaction.nonce,
        code_challenge: challenge, code_challenge_method: "S256" }).toString();
      if (options.prompt === 'none') url.searchParams.set('prompt', 'none');
      return url.href;
    } catch {
      if (this.#login === transaction) this.#login = undefined;
      throw new SccOidcError("OIDC_LOGIN_CANCELLED");
    }
  }

  /**
   * 消费精确回调、换取令牌并使用官方组件验证 ID Token 的签名和声明。
   * @param {string} callbackUrl 宿主实际收到的完整回调；禁止写入日志。
   * @returns {Promise<Readonly<{subject:string, scope:string, expiresAt:number}>>} 脱敏登录摘要。
   */
  async completeLogin(callbackUrl) {
    const transaction = this.#login;
    this.#login = undefined;
    if (!transaction || Date.now() < transaction.createdAt
        || Date.now() - transaction.createdAt >= LOGIN_TTL_MS) {
      throw new SccOidcError("OIDC_LOGIN_TRANSACTION_MISSING");
    }
    let parameters;
    try {
      const url = this.#callback(callbackUrl, this.#redirectUri, CALLBACK_PARAMETERS);
      parameters = oauth.validateAuthResponse(this.#server, this.#client, url, transaction.state);
      if (!tokenShape(parameters.get("code"))) throw new Error("OIDC_CODE_MISSING");
    } catch {
      throw new SccOidcError("OIDC_CALLBACK_REJECTED");
    }
    this.#exchanges++;
    let received;
    try {
      const startedAt = Date.now();
      const response = await oauth.authorizationCodeGrantRequest(this.#server, this.#client,
        oauth.None(), parameters, this.#redirectUri, transaction.verifier, this.#options);
      received = await response.clone().json();
      const result = await oauth.processAuthorizationCodeResponse(this.#server, this.#client,
        response, { expectedNonce: transaction.nonce, requireIdToken: true });
      const tokens = await this.#validateTokens(result, received, response, startedAt,
        transaction.nonce);
      if (transaction.generation !== this.#generation) throw new Error("OIDC_LOGIN_CANCELLED");
      this.#tokens = tokens;
      return this.#summary();
    } catch {
      const candidate = this.#candidate(received);
      if (candidate) this.#recoveryToken = candidate;
      else this.#unknownAuthorization = true;
      const confirmed = candidate ? await this.retryRevocation() : false;
      throw new SccOidcError("OIDC_LOGIN_FAILED", confirmed);
    } finally {
      this.#exchanges--;
    }
  }

  /**
   * 提供当前 Access Token；临近到期时共享一次刷新，不自动重放任何业务写请求。
   * @returns {Promise<string>} 仅供业务 Authorization Header 使用的凭据，禁止日志或持久化。
   */
  async accessToken() {
    if (this.#refresh) return this.#refresh;
    if (!this.#tokens) throw new SccOidcError("OIDC_LOGIN_REQUIRED");
    if (this.#tokens.expiresAt - Date.now() <= REFRESH_LEEWAY_MS) return this.refresh();
    return this.#tokens.accessToken;
  }

  /**
   * 显式轮换当前刷新凭据；所有并发调用共享一项任务，失败和响应未知绝不再次刷新。
   * @returns {Promise<string>} 轮换后供业务 API 使用的 Access Token。
   */
  refresh() {
    if (this.#refresh) return this.#refresh;
    if (!this.#tokens) return Promise.reject(new SccOidcError("OIDC_LOGIN_REQUIRED"));
    const previous = this.#tokens;
    const generation = this.#generation;
    this.#exchanges++;
    const operation = this.#rotate(previous, generation).finally(() => {
      this.#exchanges--;
      if (this.#refresh === operation) this.#refresh = undefined;
    });
    this.#refresh = operation;
    return operation;
  }

  /**
   * 执行一项不可自动重试的刷新；失败时销毁本地可用状态并撤销原家族。
   * @param {object} previous 当前世代原凭据集合。
   * @param {number} generation 发起刷新时的登录世代。
   * @returns {Promise<string>} 经过校验的新 Access Token。
   */
  async #rotate(previous, generation) {
    try {
      if (!previous.refreshToken) throw new Error("OIDC_REFRESH_NOT_ENABLED");
      const startedAt = Date.now();
      const response = await oauth.refreshTokenGrantRequest(this.#server, this.#client,
        oauth.None(), previous.refreshToken, this.#options);
      const raw = await response.clone().json();
      const result = await oauth.processRefreshTokenResponse(this.#server, this.#client, response);
      const tokens = await this.#validateTokens(result, raw, response, startedAt,
        previous.nonce, previous);
      if (generation !== this.#generation) throw new Error("OIDC_SESSION_CHANGED");
      this.#tokens = tokens;
      return tokens.accessToken;
    } catch {
      if (generation === this.#generation) {
        this.#logoutHint = previous.idToken;
        this.#tokens = undefined;
        this.#generation++;
      }
      this.#recoveryToken = previous.refreshToken ?? previous.accessToken;
      const confirmed = await this.retryRevocation();
      throw new SccOidcError("OIDC_REAUTHORIZATION_REQUIRED", confirmed);
    }
  }

  /**
   * 验证签名、身份绑定、令牌轮换和授权范围；不从 JWT 推导业务权益。
   * @param {object} result 官方组件处理后的响应。
   * @param {object} raw 未经类型宽松转换的原始 JSON，不能对外输出。
   * @param {Response} response 供官方组件验证应用层签名的同一响应对象。
   * @param {number} startedAt 请求开始时刻，保守计算本地到期时间。
   * @param {string} nonce 原始登录 nonce。
   * @param {object} [previous] 刷新前的已验证身份和范围。
   * @returns {Promise<object>} 仅在私有内存使用的令牌集合。
   */
  async #validateTokens(result, raw, response, startedAt, nonce, previous) {
    if (result.token_type !== "bearer" || !tokenShape(result.access_token)
        || !Number.isSafeInteger(raw.expires_in) || raw.expires_in <= 0
        || raw.expires_in > MAX_ACCESS_LIFETIME_SECONDS
        || result.refresh_token !== undefined && !tokenShape(result.refresh_token)
        || previous && (!result.refresh_token || result.refresh_token === previous.refreshToken)) {
      throw new Error("OIDC_TOKEN_RESPONSE_REJECTED");
    }
    const scope = result.scope ?? previous?.scope ?? this.#scope;
    const granted = scopes(scope);
    const allowed = new Set(scopes(previous?.scope ?? this.#scope));
    if (granted.some(value => !allowed.has(value))) throw new Error("OIDC_SCOPE_EXPANDED");
    let claims = previous?.claims;
    if (result.id_token !== undefined) {
      if (!tokenShape(result.id_token)) throw new Error("OIDC_ID_TOKEN_INVALID");
      await oauth.validateApplicationLevelSignature(this.#server, response, this.#options);
      claims = oauth.getValidatedIdTokenClaims(result);
      const now = Date.now() / 1000;
      if (claims.azp !== undefined && claims.azp !== this.#client.client_id
          || !Number.isSafeInteger(claims.iat) || !Number.isSafeInteger(claims.exp)
          || claims.iat > now || claims.exp <= claims.iat
          || claims.exp - claims.iat > MAX_ID_LIFETIME_SECONDS
          || claims.auth_time !== undefined
            && (!Number.isSafeInteger(claims.auth_time) || claims.auth_time > now)
          || claims.nonce !== undefined && claims.nonce !== nonce
          || previous && (claims.sub !== previous.claims.sub
            || claims.auth_time !== previous.claims.auth_time)) {
        throw new Error("OIDC_IDENTITY_CHANGED");
      }
    }
    if (!claims) throw new Error("OIDC_ID_TOKEN_MISSING");
    const expiresAt = startedAt + raw.expires_in * 1000;
    if (expiresAt <= Date.now()) throw new Error("OIDC_ACCESS_TOKEN_EXPIRED");
    return { accessToken: result.access_token, refreshToken: result.refresh_token,
      idToken: result.id_token ?? previous?.idToken, claims, scope, nonce, expiresAt };
  }

  /**
   * 立即清除本地登录并请求中心撤销；可另由系统浏览器完成全登录 OIDC 退出。
   * @returns {Promise<Readonly<{revocationConfirmed:boolean, endSessionUrl:string|null}>>}
   * 本次已知家族的撤销回执及需浏览器打开的退出地址；地址含 ID Token，禁止日志。
   */
  async logout() {
    const previous = this.#tokens;
    this.#tokens = undefined;
    this.#login = undefined;
    this.#generation++;
    if (previous?.idToken) this.#logoutHint = previous.idToken;
    const endSessionUrl = this.beginLogout();
    if (previous) this.#recoveryToken = previous.refreshToken ?? previous.accessToken;
    const confirmed = await this.retryRevocation();
    return Object.freeze({ revocationConfirmed: confirmed && this.#exchanges === 0,
      endSessionUrl });
  }

  /**
   * 为尚未完成的浏览器退出重新生成一次性事务；旧回调随即失效。
   * @returns {string|null} 含身份提示的退出地址，禁止记录或持久化。
   */
  beginLogout() {
    if (this.#tokens) throw new SccOidcError("OIDC_LOGOUT_REQUIRED");
    if (!this.#logoutHint || !this.#postLogoutRedirectUri) return null;
    this.#logout = { state: oauth.generateRandomState(), createdAt: Date.now() };
    const url = new URL(this.#server.end_session_endpoint);
    url.search = new URLSearchParams({ id_token_hint: this.#logoutHint,
      post_logout_redirect_uri: this.#postLogoutRedirectUri,
      state: this.#logout.state, client_id: this.#client.client_id }).toString();
    return url.href;
  }

  /**
   * 仅重试幂等撤销；不会拿旧 Token 再次刷新，失败凭据仍仅保留在私有内存。
   * @returns {Promise<boolean>} 是否已确认所有已知凭据撤销且不存在未知换码结果。
   */
  retryRevocation() {
    if (this.#revocation) return this.#revocation;
    const token = this.#recoveryToken;
    if (!token) return Promise.resolve(!this.#unknownAuthorization);
    const operation = (async () => {
      try {
        const response = await oauth.revocationRequest(this.#server, this.#client,
          oauth.None(), token, this.#options);
        await oauth.processRevocationResponse(response);
        if (this.#recoveryToken === token) this.#recoveryToken = undefined;
        return !this.#recoveryToken && !this.#unknownAuthorization;
      } catch {
        return false;
      }
    })().finally(() => {
      if (this.#revocation === operation) this.#revocation = undefined;
    });
    this.#revocation = operation;
    return operation;
  }

  /**
   * 验证精确的退出回调和一次性 state；回调本身不代替中心凭据撤销回执。
   * @param {string} callbackUrl 浏览器实际返回的完整退出回调。
   * @returns {void}
   */
  completeLogout(callbackUrl) {
    const transaction = this.#logout;
    this.#logout = undefined;
    try {
      if (!transaction || Date.now() < transaction.createdAt
          || Date.now() - transaction.createdAt >= LOGIN_TTL_MS) {
        throw new Error("OIDC_LOGOUT_TRANSACTION_MISSING");
      }
      const url = this.#callback(callbackUrl, this.#postLogoutRedirectUri, new Set(["state"]));
      if (url.searchParams.get("state") !== transaction.state) throw new Error("OIDC_STATE_INVALID");
      this.#logoutHint = undefined;
    } catch {
      throw new SccOidcError("OIDC_LOGOUT_CALLBACK_REJECTED");
    }
  }

  /**
   * 严格匹配回调地址并拒绝重复、片段及非本流程参数。
   * @param {string} value 实际回调。
   * @param {string} expected 登记回调。
   * @param {Set<string>} allowed 当前流程允许的参数名。
   * @returns {URL} 已校验地址。
   */
  #callback(value, expected, allowed) {
    if (typeof value !== "string" || value.length > MAX_CALLBACK_LENGTH) {
      throw new Error("OIDC_CALLBACK_INVALID");
    }
    const url = new URL(value);
    const target = new URL(expected);
    if (url.origin !== target.origin || url.pathname !== target.pathname
        || url.username || url.password || url.hash) throw new Error("OIDC_CALLBACK_INVALID");
    for (const name of url.searchParams.keys()) {
      if (!allowed.has(name) || url.searchParams.getAll(name).length !== 1) {
        throw new Error("OIDC_CALLBACK_INVALID");
      }
    }
    return url;
  }

  /** 从收到的响应选择可撤销凭据；不验证或使用其承载的身份。 */
  #candidate(response) {
    if (tokenShape(response?.refresh_token)) return response.refresh_token;
    if (tokenShape(response?.access_token)) return response.access_token;
    return undefined;
  }

  /** 返回不含任何凭据的冻结登录摘要。 */
  #summary() {
    return Object.freeze({ subject: this.#tokens.claims.sub, scope: this.#tokens.scope,
      expiresAt: this.#tokens.expiresAt });
  }
}
