import type { SccClient, SoftwareUpdateQuery, SoftwareUpdateVerifier, VerifiedSoftwareUpdate } from "./index.js";

/** Node专用下载选项；不传入浏览器打包入口。 */
export type SoftwareUpdateDownloadOptions = ConstructorParameters<typeof SccClient>[0] & {
  /** 更新查询及下载必须提供当前用户令牌，不适用公开报价的匿名配置。 */
  accessTokenProvider: () => string | Promise<string>;
  /** 本软件固定身份和本机已安装序号。 */ query: SoftwareUpdateQuery;
  /** 已匹配预置指纹的验签器。 */ verifier: SoftwareUpdateVerifier;
  /** 已存在的本机私有缓存绝对目录，Windows ACL由宿主配置；禁止链接和共享目录。 */ directory: string;
  /** 本次授权意图的稳定幂等键。 */ idempotencyKey: string;
  /** 完整二进制读取时限，默认300000毫秒；授权先到期时提前截止。 */ downloadTimeoutMs?: number;
  /** 取消下载，残缺文件不交付。 */ signal?: AbortSignal;
};

/** 本次完整且已核验的文件；宿主负责提示、安装前复核和使用后清理。 */
export interface PreparedSoftwareUpdate {
  /** 已核验的签名发布与文件元数据。 */ readonly update: VerifiedSoftwareUpdate;
  /** 专用缓存子目录内的完整文件路径，不自动执行。 */ readonly file: string;
}

/** 实时查询、验签、授权和流式校验后交付全新文件；无更新返回null。 */
export function prepareSoftwareUpdate(options: SoftwareUpdateDownloadOptions): Promise<PreparedSoftwareUpdate | null>;
