/**
 * 中控 Problem Details 对应的稳定 SDK 异常。
 */
export class SccApiError extends Error {
  /**
   * @param {{status:number, code?:string, detail?:string, requestId?:string}} problem 错误事实。
   */
  constructor({ status, code, detail, requestId }) {
    super(detail || "SCC API 请求失败");
    this.name = "SccApiError";
    /** @type {number} HTTP 状态码。 */
    this.status = status;
    /** @type {string} 稳定业务错误码。 */
    this.code = code || "UNKNOWN";
    /** @type {string|undefined} 端到端请求编号。 */
    this.requestId = requestId;
  }
}

/**
 * 将受限读取的Problem正文映射为错误；HTTP状态来自响应本身，正文status只作未使用的附加信息。
 * @param {number} status 实际HTTP状态，不能从正文覆盖。
 * @param {unknown} problem 已解析的错误正文，允许未来附加字段。
 * @param {string|null} requestIdHeader 仅用于非法正文的响应追踪头。
 * @returns {SccApiError} 保留真实HTTP状态、不强制转换异常字段的错误。
 */
export function apiProblemError(status, problem, requestIdHeader) {
  if (!problem || typeof problem !== "object" || Array.isArray(problem)
      || ["code", "detail", "requestId"].some(field => problem[field] != null && typeof problem[field] !== "string")) {
    return new SccApiError({ status, code: "INVALID_ERROR_RESPONSE",
      detail: "SCC API 返回了无法解析的错误响应", requestId: requestIdHeader ?? undefined });
  }
  return new SccApiError({ status, code: problem.code ?? undefined,
    detail: problem.detail ?? undefined, requestId: problem.requestId ?? undefined });
}
