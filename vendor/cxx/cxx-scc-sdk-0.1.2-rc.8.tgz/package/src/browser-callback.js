import { SccOidcError } from "./oidc.js";
import { secureUrl } from "./oidc-transport.js";

/** 回调消息只承载一次性协议响应，绝不承载 Token 或 PKCE verifier。 */
export const CALLBACK_MESSAGE = "scc.oidc.callback.v1";
/** 与核心 OIDC 回调一致的输入上限。 */
const MAX_CALLBACK_LENGTH = 16384;
/** 授权码模式的标准参数，不接受隐式凭据或任意业务参数。 */
const LOGIN_PARAMETERS = new Set([
  "code", "state", "iss", "error", "error_description", "error_uri", "scope"
]);
const LOGOUT_PARAMETERS = new Set(["state"]);

/** 验证浏览器部署地址；本地 HTTP 仅允许数值回环，与中心来源规则一致。 */
export function browserUrl(value, allowLoopbackHttp) {
  const url = secureUrl(value, allowLoopbackHttp);
  if (url.protocol === "http:" && !["127.0.0.1", "[::1]"].includes(url.hostname)) {
    throw new Error("OIDC_BROWSER_CONFIGURATION_REJECTED");
  }
  return url;
}

/** 严格筛选回调；核心会话仍须独立校验 state、issuer、签名、nonce 和授权响应。 */
export function callbackUrl(value, expected, kind) {
  if (typeof value !== "string" || value.length > MAX_CALLBACK_LENGTH) return undefined;
  try {
    const url = new URL(value);
    const allowed = kind === "login" ? LOGIN_PARAMETERS : LOGOUT_PARAMETERS;
    if (url.origin !== expected.origin || url.pathname !== expected.pathname
        || url.username || url.password || url.hash) return undefined;
    for (const name of url.searchParams.keys()) {
      if (!allowed.has(name) || url.searchParams.getAll(name).length !== 1) return undefined;
    }
    const state = url.searchParams.get("state");
    if (!state || !/^[\x21-\x7E]+$/.test(state)) return undefined;
    if (kind === "login" && (url.searchParams.has("code") === url.searchParams.has("error"))) {
      return undefined;
    }
    return url;
  } catch {
    return undefined;
  }
}

/**
 * 在专用回调页最先执行：清除地址中的协议参数，向固定同源父页传递一次性响应。
 * 不读取 referrer/query 中的目标来源，不执行换码、不存储凭据、不主动关闭窗口。
 * @param {import('./browser.js').SccBrowserCallbackOptions} configuration 固定部署配置。
 * @param {Window} [browserWindow] 可信窗口；默认当前 window，仅供宿主适配或测试注入。
 * @returns {void} 发送只代表回调已转交，不代表登录、支付或中心退出成功。
 */
export function completeSccBrowserCallback(configuration, browserWindow = globalThis.window) {
  try {
    const actual = browserWindow.location.href;
    // 即使参数或配置错误，也先清除敏感 query/fragment；不保留旧 history.state。
    browserWindow.history.replaceState(null, "", browserWindow.location.pathname);
    const { redirectUri, openerOrigin, kind, allowLoopbackHttp = false, transport = 'popup' } = configuration;
    const expected = browserUrl(redirectUri, allowLoopbackHttp);
    const origin = browserUrl(openerOrigin, allowLoopbackHttp).origin;
    if (origin !== openerOrigin || expected.origin !== origin
        || !["login", "logout"].includes(kind)) throw new Error();
    const url = callbackUrl(actual, expected, kind);
    if (!['popup', 'embedded'].includes(transport)) throw new Error();
    const receiver = transport === 'embedded' ? browserWindow.parent : browserWindow.opener;
    if (!url || !receiver || receiver === browserWindow
        || (transport === 'embedded' && receiver !== browserWindow.top)) throw new Error();
    receiver.postMessage({ type: CALLBACK_MESSAGE, kind, url: url.href }, origin);
  } catch {
    throw new SccOidcError("OIDC_BROWSER_CALLBACK_REJECTED");
  }
}
