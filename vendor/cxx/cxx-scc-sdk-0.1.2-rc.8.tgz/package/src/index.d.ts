export interface MoneyValue {
  amountMinor: string;
  currency: string;
}

/** 中心已记录的资金状态，不单独证明已履约。 */
export type PaymentStatus = "CREATED" | "PENDING" | "AUTHORIZED" | "SUCCEEDED" | "FAILED" | "CLOSED";

/** 升级取消回执，不作为退款或使用资格证明。 */
export interface PaymentCancellationResult {
  /** 本次处理的原支付公开编号。 */
  readonly paymentNo: string;
  /** 原升级订单公开编号。 */
  readonly orderNo: string;
  /** 已取消、已有收款，或同订单其他支付仍待处置。 */
  readonly cancellationStatus: "CANCELLED" | "PAYMENT_RECEIVED" | "OTHER_PAYMENT_UNRESOLVED";
  /** 当前中心资金事实；另一支付收款不意味着本支付已收款。 */
  readonly paymentStatus: PaymentStatus;
  /** 中心订单状态，可能尚未异步收敛。 */
  readonly orderStatus: "OPEN" | "CLOSED" | "CANCELLED" | "EXPIRED";
}

/** 渠道查单观察与中心资金事实分别保留，不推断取消或退款。 */
export interface PaymentReconciliationResult {
  /** 原支付公开编号。 */
  readonly paymentNo: string;
  /** 原订单公开编号。 */
  readonly orderNo: string;
  /** 本次可信渠道观察，可能早于并发成功回调。 */
  readonly queryStatus: "WAITING" | "SUCCEEDED" | "CLOSED_UNRESOLVED" | "NOT_FOUND";
  /** 当前中心资金事实，已收款不得被较早观察覆盖。 */
  readonly paymentStatus: PaymentStatus;
}

/** 升级目标，不能指定其他账户。 */
export interface UpgradeTarget {
  /** 软件代码。 */
  productCode: string;
  /** 目标套餐代码。 */
  targetPlanCode: string;
  /** 目标不可变价格代码。 */
  targetPriceCode: string;
}

/** 用户确认的升级意图；金额与版本禁止转为Number。 */
export interface UpgradeCheckoutRequest extends UpgradeTarget {
  /** 报价中的当前周期公开编号。 */
  sourcePeriodNo: string;
  /** 报价中的订阅版本精确字符串。 */
  subscriptionVersion: string;
  /** 报价中的规则版本精确字符串。 */
  policyVersion: string;
  /** 用户同意的金额上限，不是客户端指定的应收金额。 */
  maximumPayable: MoneyValue;
  /** 软件允许的渠道，零差价也必须填写。 */
  paymentChannel: string;
}

/** 中心升级规则，仅供展示和确认，不在SDK执行。 */
export interface UpgradePolicyResult {
  /** 归属软件代码。 */
  productCode: string;
  /** 来源套餐代码。 */
  sourcePlanCode: string;
  /** 目标套餐代码。 */
  targetPlanCode: string;
  /** 当前路径是否启用。 */
  enabled: boolean;
  /** 全价、完整差价或剩余时间差价。 */
  chargeMode: string;
  /** 原标价或净实付基数；全价方式为空。 */
  priceBasis: string | null;
  /** IMMEDIATE立即、CURRENT_PERIOD_END当前周期末、BOOKED_PERIODS_END全部已取得期限末生效。 */
  effectiveMode: string;
  /** 保持原到期日或新目标周期。 */
  termRule: string;
  /** 规则版本精确字符串。 */
  version: string;
  /** 时间差价舍入方式；其他方式为空。 */
  rounding: string | null;
}

/** 本人升级预览；不预留价格、不付款、不授予权益。 */
export interface UpgradeQuoteResult {
  /** 软件代码。 */
  productCode: string;
  /** 本人订阅公开编号。 */
  subscriptionNo: string;
  /** 当前订阅版本精确字符串。 */
  subscriptionVersion: string;
  /** 当前有效周期公开编号。 */
  sourcePeriodNo: string;
  /** 来源不可变价格代码。 */
  sourcePriceCode: string;
  /** 目标价格代码。 */
  targetPriceCode: string;
  /** 此次采用的中心规则。 */
  policy: UpgradePolicyResult;
  /** 来源价值基数；全价为空，不代表可退款额。 */
  sourceBasis: MoneyValue | null;
  /** 目标目录全价。 */
  targetPrice: MoneyValue;
  /** 中心计算的应付预览。 */
  payable: MoneyValue;
  /** 中心UTC计算时刻。 */
  evaluatedAt: string;
  /** 原周期包含起点。 */
  sourcePeriodStart: string;
  /** 当前计费来源的原排他终点，不代表全部已取得期限末端。 */
  sourcePeriodEnd: string;
  /** 预览生效时刻，支付后由中心复核。 */
  effectiveAt: string;
  /** 预览目标排他到期时刻。 */
  targetPeriodEnd: string;
}

export interface SubscriptionResult {
  subscriptionNo: string;
  status: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd?: boolean;
  version: number;
}

export interface CheckoutResult {
  orderNo: string;
  paymentNo: string | null;
  amount: MoneyValue;
  orderPaymentStatus: string;
  fulfillmentStatus: string;
  paymentStatus: string | null;
  expiresAt: string;
  actionType: string;
  actionValue: string | null;
}

/** 本人订单快照，不是软件使用授权；金额为规范十进制字符串。 */
export interface OrderResult {
  /** 本人订单的26位公开编号。 */
  readonly orderNo: string;
  /** 普通购买、续费或套餐变更。 */
  readonly orderType: "NEW" | "RENEW" | "CHANGE";
  /** 中心确认的应付金额，最小货币单位为精确字符串。 */
  readonly payable: Readonly<MoneyValue>;
  /** 成交时的原价，不随目录变化。 */
  readonly original: Readonly<MoneyValue>;
  /** 原价减应付；升级抵扣不是现金退款。 */
  readonly discount: Readonly<MoneyValue>;
  /** 成交活动修订，无活动时为 null。 */
  readonly discountRevisionNo: string | null;
  /** 订单生命周期，不代表资金或授权结果。 */
  readonly orderStatus: "OPEN" | "CLOSED" | "CANCELLED" | "EXPIRED";
  /** 中心当前资金状态，与履约分开判断。 */
  readonly paymentStatus: "UNPAID" | "NOT_REQUIRED" | "PAID" | "PARTIALLY_REFUNDED" | "REFUNDED";
  /** 开通处理结果，不替代当前使用资格查询。 */
  readonly fulfillmentStatus: "NOT_STARTED" | "PROCESSING" | "SUCCEEDED" | "FAILED";
  /** 支付等待截止时间，不是订阅有效期。 */
  readonly expiresAt: string;
  /** 非负安全整数，超出 JavaScript 精确整数范围的响应被拒绝。 */
  readonly version: number;
}

export interface OfferResult {
  productCode: string;
  planCode: string;
  priceCode: string;
  amount: MoneyValue;
  interval: "MONTH" | "YEAR";
  intervalCount: number;
  trialDays: number;
}

/** 本人活动报价，不预留资格；金额均为字符串，SDK 不自行计价。 */
export interface DiscountQuoteResult {
  productCode: string;
  planCode: string;
  priceCode: string;
  activityCode: string;
  discountRevisionNo: string;
  original: MoneyValue;
  discount: MoneyValue;
  payable: MoneyValue;
  evaluatedAt: string;
}

/** 当前请求的中央判定；validUntil 不是缓存或离线许可期限。 */
export interface ProductAccessResult {
  productCode: string;
  allowed: boolean;
  reason: "ALLOWED" | "USER_NOT_ACTIVE" | "ACCOUNT_NOT_ACTIVE" | "NO_SUBSCRIPTION"
    | "SUBSCRIPTION_NOT_ACTIVE" | "OUTSIDE_ACCESS_PERIOD";
  evaluatedAt: string;
  validUntil: string | null;
}

/** 当前用户的功能资格；不消耗配额，失败不得使用历史允许结果。 */
export interface FeatureAccessResult {
  productCode: string;
  featureCode: string;
  allowed: boolean;
  reason: ProductAccessResult["reason"] | "FEATURE_NOT_INCLUDED";
  evaluatedAt: string;
  validUntil: string | null;
}

export interface PkceSession {
  codeVerifier: string;
  codeChallenge: string;
  state: string;
  nonce: string;
}

/** 当前软件允许的新支付渠道；结账时仍须由中心再次检查。 */
export interface PaymentMethodsResult {
  readonly productCode: string;
  readonly channels: readonly string[];
}

export class SccApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId?: string;
}

/** 公开候选密钥，不是客户端自动信任的根。 */
export interface SoftwareUpdatePublicKey {
  /** 签名密钥编号。 */ readonly kid: string;
  /** 固定RSA类型。 */ readonly kty: "RSA";
  /** 固定签名算法。 */ readonly alg: "RS256";
  /** 固定签名用途。 */ readonly use: "sig";
  /** Base64url编码的RSA模数。 */ readonly n: string;
  /** Base64url编码的RSA指数。 */ readonly e: string;
}

/** 当前更新公钥候选集合。 */
export interface SoftwareUpdateKeys {
  /** 活跃及轮换保留公钥，不含私钥。 */ readonly keys: readonly SoftwareUpdatePublicKey[];
}

/** 中央短期下载回执；必须与签名元数据逐项匹配。 */
export interface SoftwareDownloadGrant {
  /** 授权公开号，不是独立访问凭据。 */ readonly grantNo: string;
  /** 软件代码。 */ readonly productCode: string;
  /** 不可变发布号。 */ readonly publicationNo: string;
  /** 平台目标号。 */ readonly targetNo: string;
  /** 不可变文件号。 */ readonly artifactNo: string;
  /** 精确字节长度字符串。 */ readonly byteLength: string;
  /** 完整文件SHA-256。 */ readonly sha256: string;
  /** 排他失效UTC时刻，原意图重试不延期。 */ readonly expiresAt: string;
}

/** 本软件固定身份和本机安装状态。 */
export interface SoftwareUpdateQuery {
  /** 软件稳定代码。 */ readonly productCode: string;
  /** 操作系统代码。 */ readonly platformCode: string;
  /** 处理器架构。 */ readonly architectureCode: string;
  /** 规范十进制序号，不经Number转换；首次安装为0。 */ readonly installedSequenceNo: string;
}

/** 签名覆盖的文件元数据；不代表文件字节已经核验。 */
export interface SoftwareUpdateFile {
  /** 更新目标编号。 */ readonly targetNo: string;
  /** 不可变文件编号。 */ readonly artifactNo: string;
  /** 文件业务代码。 */ readonly artifactCode: string;
  /** 操作系统代码。 */ readonly platformCode: string;
  /** 处理器架构。 */ readonly architectureCode: string;
  /** 允许升级的最低已安装序号。 */ readonly minimumSequenceNo: string;
  /** 精确字节长度的十进制字符串。 */ readonly byteLength: string;
  /** 文件SHA-256小写十六进制摘要。 */ readonly sha256: string;
}

/** 已通过预置信任根、签名和兼容规则核验的更新。 */
export interface VerifiedSoftwareUpdate {
  /** 发布编号。 */ readonly publicationNo: string;
  /** 软件稳定代码。 */ readonly productCode: string;
  /** 可展示版本代码。 */ readonly versionCode: string;
  /** 版本修订编号。 */ readonly revisionNo: string;
  /** 单调递增序号的精确字符串。 */ readonly sequenceNo: string;
  /** 发布UTC时间，保留服务端精度。 */ readonly publishedAt: string;
  /** 原始紧凑JWS，不可当作下载凭据。 */ readonly signedManifest: string;
  /** 实际签名密钥匹配的RFC7638指纹。 */ readonly signingKeyThumbprint: string;
  /** 本机匹配的签名文件目标。 */ readonly target: SoftwareUpdateFile;
}

/** 仅使用createSoftwareUpdateVerifier创建，不接受自定义绕过验签的回调。 */
export interface SoftwareUpdateVerifier {
  /** 核验中央响应；无更新返回null，其他失败抛出异常。 */
  verify(response: unknown, query: SoftwareUpdateQuery): Promise<VerifiedSoftwareUpdate | null>;
}

/** 将候选公钥与软件发布渠道预置的指纹匹配；禁止从本次HTTP响应自动生成信任指纹。 */
export function createSoftwareUpdateVerifier(options: {
  jwks: SoftwareUpdateKeys;
  pinnedThumbprints: readonly string[];
}): Promise<SoftwareUpdateVerifier>;

/** 软件模式独立于套餐和价格，配置版本为精确十进制字符串。 */
export interface SoftwareUsagePolicy {
  productCode: string;
  name: string;
  mode: 'FREE' | 'SUBSCRIPTION';
  version: string;
}
/** 本人订阅展示资料，不参与资格判断；到期后仍可返回原周期。 */
export interface RuntimeSubscriptionSummary {
  /** 套餐当前名称。 */ readonly planName: string;
  /** 当前覆盖周期开始；无覆盖时为最近订阅记录的周期开始。 */ readonly startsAt: string;
  /** 所选订阅周期真实排他结束时间，不是授权缓存期限。 */ readonly expiresAt: string;
}
/** 当前账户的软件实时资格，不是可重复使用的离线许可。 */
export interface RuntimeSoftwareDecision extends Omit<SoftwareUsagePolicy, 'version' | 'mode'> {
  /** 未登记软件的可信管理员开发回执为空，不创建或推断收费模式。 */
  mode: SoftwareUsagePolicy['mode'] | null;
  allowed: boolean;
  reason: string;
  evaluatedAt: string;
  validUntil: string | null;
  /** 仅本人且客户端可读的软件；旧服务、无订阅或不可见时省略。 */
  subscription?: RuntimeSubscriptionSummary;
}
export class SccClient {
  /** 无需登录或报价，批量读取已发布软件的免费/订阅模式；不授予使用资格。 */
  getSoftwareUsagePolicies(productCodes: readonly string[]): Promise<readonly SoftwareUsagePolicy[]>;
  /** 对已验证主体和客户端实时批量核验资格，响应不作离线许可。 */
  getRuntimeSoftwareAccess(productCodes: readonly string[]): Promise<readonly RuntimeSoftwareDecision[]>;
  /** 读取已认证本人的展示名称及商业账户公开号。 */
  getCurrentUser(): Promise<{subjectId: string; accountId: string; displayName: string; status: string; zoneId: string}>;
  /** 独立points.read权限，本人实时余额，不是离线扣分依据。 */
  getPointBalance(): Promise<PointBalanceResult>;
  /** 第一页省略cursor；续页原样传入nextCursor，数量默认20、最多100。 */
  getPointLedger(options?: { limit?: number; cursor?: string | null }): Promise<PointLedgerPageResult>;
  constructor(options: {
    baseUrl: string;
    /** 仅getOffer可省略；其他接口缺少提供者时在本地拒绝，不发送请求。令牌不可为空或包含空白/控制字符。 */
    accessTokenProvider?: () => string | Promise<string>;
    /** 可信Fetch实现；SDK另行限制响应读取，禁止重定向、Cookie与引用来源。 */
    fetchImpl?: typeof fetch;
    /** 1至300000的整数，默认10000；取令牌和每次完整HTTP交换分别使用此上限。 */
    timeoutMs?: number;
    /** 0至3的整数，默认2；仅确定的429/502/503/504响应可有限重试。 */
    maxRetries?: number;
  });
  static newIdempotencyKey(): string;
  /** 匿名报价：不取令牌、不带Cookie、不缓存或自动重试，完整响应受超时及256KiB上限约束。 */
  getOffer(request: { productCode: string; planCode: string; priceCode: string }): Promise<OfferResult>;
  checkout(request: { productCode: string; planCode: string; priceCode: string; paymentChannel?: string; activityCode?: string; discountRevisionNo?: string }, idempotencyKey: string): Promise<CheckoutResult>;
  /** 实时读取本人原订单，不付款、不重建订单，错误不回退到历史快照。 */
  getOrder(orderNo: string): Promise<OrderResult>;
  quoteDiscount(request: { productCode: string; planCode: string; priceCode: string; activityCode: string }): Promise<DiscountQuoteResult>;
  /** 本人升级报价；不自动确认，金额和版本为精确字符串。 */
  quoteUpgrade(request: UpgradeTarget): Promise<UpgradeQuoteResult>;
  /** 用户明确确认后调用；409不自动重报价，同意图重试固定使用同一键。 */
  upgradeCheckout(request: UpgradeCheckoutRequest, idempotencyKey: string): Promise<CheckoutResult>;
  /** 取消本人未付款升级，以原支付编号恢复；已有收款或其他支付待处置不算取消成功。 */
  cancelUpgradePayment(paymentNo: string): Promise<PaymentCancellationResult>;
  /** 本人原购买或升级支付查单；关闭或未找到不证明取消、退款或权益。 */
  reconcilePayment(paymentNo: string): Promise<PaymentReconciliationResult>;
  startTrial(request: { productCode: string; planCode: string; priceCode: string }, idempotencyKey: string): Promise<SubscriptionResult>;
  redeem(code: string, idempotencyKey: string): Promise<SubscriptionResult>;
  getSubscription(subscriptionNo: string): Promise<SubscriptionResult>;
  getProductAccess(productCode: string): Promise<ProductAccessResult>;
  getFeatureAccess(productCode: string, featureCode: string): Promise<FeatureAccessResult>;
  /** 读取候选JWKS，尚未建立信任。 */
  getSoftwareUpdateKeys(): Promise<SoftwareUpdateKeys>;
  /** 申请短期回执；原意图重试复用幂等键，回执本身不能建立文件信任。 */
  issueSoftwareDownloadGrant(productCode: string, targetNo: string, idempotencyKey: string): Promise<SoftwareDownloadGrant>;
  /** 查询并核验更新；不下载、不安装，不替代中央资格检查。 */
  checkSoftwareUpdate(query: SoftwareUpdateQuery, verifier: SoftwareUpdateVerifier): Promise<VerifiedSoftwareUpdate | null>;
  getPaymentMethods(productCode: string): Promise<PaymentMethodsResult>;
}

/** 本人余额；数量和版本不可转换为JavaScript Number。 */
export interface PointBalanceResult {
  readonly programNo: string;
  readonly name: string;
  readonly enabled: boolean;
  /** 未开户为空；查询不会开户。 */
  readonly walletNo: string | null;
  readonly available: string;
  readonly frozen: string;
  readonly debt: string;
  /** 钱包版本，未开户为-1。 */
  readonly version: string;
  readonly updatedAt: string | null;
}
/** 本人不可变流水，整数均为精确字符串。 */
export interface PointLedgerResult {
  readonly transactionNo: string;
  readonly type: "EARN" | "SPEND" | "REFUND" | "RECLAIM";
  readonly amount: string;
  readonly originalTransactionNo: string | null;
  readonly availableDelta: string;
  readonly frozenDelta: string;
  readonly debtDelta: string;
  readonly availableAfter: string;
  readonly frozenAfter: string;
  readonly debtAfter: string;
  readonly occurredAt: string;
}
/** 按钱包入账顺序倒序排列，不提供不稳定的偏移量分页。 */
export interface PointLedgerPageResult {
  readonly items: readonly PointLedgerResult[];
  readonly nextCursor: string | null;
}

export function createPkceSession(): Promise<PkceSession>;
export function buildAuthorizationUrl(options: {
  issuer: string;
  clientId: string;
  redirectUri: string;
  scope: string;
  session: PkceSession;
}): string;
