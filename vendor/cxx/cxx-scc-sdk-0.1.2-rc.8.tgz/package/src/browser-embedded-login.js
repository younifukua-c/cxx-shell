import { SccOidcError } from './oidc.js';
import { abortable } from './oidc-transport.js';

/** 第一方同源密码验证：只建立官方 Cookie 会话，不使用密码授权发放 OAuth 令牌。 */
export async function authenticateEmbeddedPassword(browserWindow, clientId, username, password, signal, timeoutMs) {
  if (typeof username !== 'string' || !username.trim() || username.length > 320
      || typeof password !== 'string' || !password || password.length > 1024) {
    throw new SccOidcError('OIDC_EMBEDDED_LOGIN_REJECTED');
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal?.addEventListener('abort', abort, {once: true});
  if (signal?.aborted) controller.abort();
  const timer = browserWindow.setTimeout(abort, timeoutMs);
  const endpoint = new URL('/login/embedded', browserWindow.location.origin);
  const options = {credentials: 'same-origin', redirect: 'error', cache: 'no-store',
    referrerPolicy: 'no-referrer', signal: controller.signal};
  let reader;
  try {
    endpoint.searchParams.set('client_id', clientId);
    const context = await abortable(browserWindow.fetch(endpoint.href, {...options,
      headers: {Accept: 'application/json'}}), controller.signal);
    if (context.status !== 200 || !context.headers.get('content-type')?.includes('application/json')) throw new Error();
    reader = context.body?.getReader();
    if (!reader) throw new Error();
    let length = 0;
    const chunks = [];
    for (;;) {
      const {done, value} = await abortable(reader.read(), controller.signal);
      if (done) break;
      length += value.byteLength;
      if (length > 8192) throw new Error();
      chunks.push(value);
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) {bytes.set(chunk, offset); offset += chunk.byteLength;}
    const csrf = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(bytes));
    if (!csrf || csrf.parameterName !== '_csrf' || typeof csrf.token !== 'string'
        || !/^[A-Za-z0-9_=-]{1,4096}$/.test(csrf.token)) throw new Error();
    endpoint.search = '';
    const body = new URLSearchParams({client_id: clientId, username, password, _csrf: csrf.token});
    const response = await abortable(browserWindow.fetch(endpoint.href, {...options,
      method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json'}, body}), controller.signal);
    body.delete('password');
    response.body?.cancel().catch(() => {});
    if (response.status !== 204 || response.redirected || controller.signal.aborted) throw new Error();
  } catch {
    throw new SccOidcError(controller.signal.aborted ? 'OIDC_BROWSER_CANCELLED' : 'OIDC_EMBEDDED_LOGIN_REJECTED');
  } finally {
    reader?.cancel().catch(() => {});
    signal?.removeEventListener('abort', abort);
    browserWindow.clearTimeout(timer);
    username = password = '';
  }
}
