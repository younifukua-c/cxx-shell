import { SccOidcError, SccOidcSession } from "./oidc.js";
import { browserUrl } from "./browser-callback.js";
import { BrowserPopup } from "./browser-popup.js";
import { authenticateEmbeddedPassword } from './browser-embedded-login.js';

export { completeSccBrowserCallback } from "./browser-callback.js";

/** 防止绕过发现与浏览器部署检查构造宿主。 */
const VERIFIED_BROWSER = Symbol();
/** 默认交互期限和上限，与核心十分钟事务期限分别约束。 */
const DEFAULT_INTERACTION_MS = 120000;
const MAX_INTERACTION_MS = 600000;

/**
 * 单用户浏览器公开客户端宿主；仅复用一个 SccOidcSession，不持久化任何凭据。
 * 宿主须为存活的顶层页；不适用于跨源回调、多用户 BFF 或整页重定向恢复。
 * 第一方表单模式只在宿主内创建受控同源协议帧，不提供或限定页面样式。
 */
export class SccBrowserOidc {
  /** 唯一认证会话，凭据不复制到宿主字段。 */
  #session;
  /** 顶层浏览器窗口。 */
  #window;
  /** 固定登录回调。 */
  #redirect;
  /** 固定退出回调。 */
  #postLogout;
  /** 用户交互最大毫秒数。 */
  #timeout;
  /** 当前存在未结束的登录或退出，禁止第二次交互覆盖。 */
  #busy = false;
  /** 未完成退出的私有协议地址，只供同一次退出重试，不记录、不持久化。 */
  #pendingLogout;
  /** 服务器明确预批准的同源第一方表单模式。 */
  #embedded;
  /** 用于官方密码表单的公开客户端编号，不属于密码或凭据。 */
  #clientId;
  /** 固定签发者来源，不随官网反代的浏览器来源变化。 */
  #issuerOrigin;

  /**
   * 在用户点击前完成固定配置的发现；回调页面必须与宿主页同源。
   * @param {import('./browser.js').SccBrowserOidcOptions} configuration 非秘密部署配置。
   * @param {Window} [browserWindow] 可信窗口，默认当前 window；不从网络输入构造。
   * @returns {Promise<SccBrowserOidc>} 尚未登录的宿主。
   */
  static async discover(configuration, browserWindow = globalThis.window) {
    try {
      const { interactionTimeoutMs = DEFAULT_INTERACTION_MS, allowLoopbackHttp = false,
        redirectUri, postLogoutRedirectUri, loginMode = 'popup', embeddedProxy = false } = configuration;
      const origin = browserUrl(browserWindow.location.origin, allowLoopbackHttp).origin;
      const redirect = browserUrl(redirectUri, allowLoopbackHttp);
      const postLogout = browserUrl(postLogoutRedirectUri, allowLoopbackHttp);
      if (browserWindow.top !== browserWindow || !browserWindow.isSecureContext
          || origin !== redirect.origin || origin !== postLogout.origin
          || redirect.href === postLogout.href || !['popup', 'embedded'].includes(loginMode)
          || typeof embeddedProxy !== 'boolean'
          || (loginMode === 'embedded' && ((!embeddedProxy && browserUrl(configuration.issuer, allowLoopbackHttp).origin !== origin)
            || browserUrl(configuration.issuer, allowLoopbackHttp).pathname !== '/'))
          || !Number.isSafeInteger(interactionTimeoutMs) || interactionTimeoutMs < 100
          || interactionTimeoutMs > MAX_INTERACTION_MS) throw new Error();
      const session = await SccOidcSession.discover(configuration);
      return new SccBrowserOidc(VERIFIED_BROWSER, session, browserWindow,
        redirect, postLogout, interactionTimeoutMs, loginMode === 'embedded', configuration.clientId,
        browserUrl(configuration.issuer, allowLoopbackHttp).origin);
    } catch {
      throw new SccOidcError("OIDC_BROWSER_CONFIGURATION_REJECTED");
    }
  }

  /** 内部构造，仅接受已验证的核心会话。 */
  constructor(verified, session, browserWindow, redirect, postLogout, timeout, embedded, clientId, issuerOrigin) {
    if (verified !== VERIFIED_BROWSER) throw new SccOidcError("OIDC_BROWSER_CONFIGURATION_REJECTED");
    this.#session = session;
    this.#window = browserWindow;
    this.#redirect = redirect;
    this.#postLogout = postLogout;
    this.#timeout = timeout;
    this.#embedded = embedded;
    this.#clientId = clientId;
    this.#issuerOrigin = issuerOrigin;
  }

  /**
   * 从真实用户点击直接调用；同步创建弹窗，随后完成 S256、回调和官方 OIDC 验证。
   * @param {AbortSignal} [signal] 中止本次交互；不重试授权码或恢复迟到身份。
   * @returns {Promise<Readonly<{subject:string,scope:string,expiresAt:number}>>} 无凭据登录摘要。
   */
  async login(signal) {
    if (this.#embedded) throw new SccOidcError('OIDC_EMBEDDED_CREDENTIALS_REQUIRED');
    return this.#login(undefined, undefined, signal);
  }

  /** 第一方同源页面直接使用账号密码；不发放密码授权令牌，不保存输入。 */
  async loginEmbedded(username, password, signal) {
    if (!this.#embedded) throw new SccOidcError('OIDC_BROWSER_CONFIGURATION_REJECTED');
    return this.#login(username, password, signal);
  }

  /** 只利用已有第一方Cookie会话恢复PKCE登录，不保存令牌，也不展示或代填密码。 */
  async restore(signal) {
    if (!this.#embedded) throw new SccOidcError('OIDC_BROWSER_CONFIGURATION_REJECTED');
    return this.#login(undefined, undefined, signal, true);
  }

  /** 所有宿主复用唯一的授权、取消、撤销和 OIDC 验证生命周期。 */
  async #login(username, password, signal, restoring = false) {
    this.#claim();
    let popup;
    let started = false;
    let clearing;
    try {
      if (this.#pendingLogout) throw new SccOidcError("OIDC_BROWSER_LOGOUT_PENDING");
      popup = new BrowserPopup(this.#window, this.#redirect, "login", this.#timeout, signal,
        () => { clearing ??= this.#clearLogin(); }, this.#embedded, this.#issuerOrigin);
      if (this.#embedded && !restoring) {
        await authenticateEmbeddedPassword(this.#window, this.#clientId, username, password, signal, this.#timeout);
        username = password = undefined;
      }
      const url = await this.#session.beginLogin(restoring ? {prompt: 'none'} : undefined);
      started = true;
      popup.navigate(url);
      const callback = await popup.response;
      if (popup.cancelled) throw new SccOidcError(popup.cancelled);
      const summary = await this.#session.completeLogin(callback);
      if (popup.cancelled) throw new SccOidcError(popup.cancelled);
      return summary;
    } catch (error) {
      let confirmed = error instanceof SccOidcError && error.revocationConfirmed;
      if (clearing || started) confirmed = (await (clearing ?? this.#clearLogin())).revocationConfirmed;
      throw new SccOidcError(popup?.cancelled ?? (error instanceof SccOidcError
        ? error.code : "OIDC_BROWSER_LOGIN_FAILED"), confirmed);
    } finally {
      username = password = undefined;
      popup?.dispose();
      this.#busy = false;
    }
  }

  /** 提供核心会话的 Access Token；交互期间不可使用尚未交付或正在退出的身份。 */
  async accessToken() {
    if (this.#busy || this.#pendingLogout) throw new SccOidcError("OIDC_LOGIN_REQUIRED");
    return this.#session.accessToken();
  }

  /** 显式 single-flight 刷新，不重试任何业务请求或结果未知的刷新。 */
  async refresh() {
    if (this.#busy || this.#pendingLogout) throw new SccOidcError("OIDC_LOGIN_REQUIRED");
    return this.#session.refresh();
  }

  /**
   * 立即清除本地登录并撤销家族，再完成中心浏览器退出；再次调用只重试未完成退出。
   * 弹窗被拦截/关闭也不会保留可用 Token，且不丢失内存中的原退出地址。
   * @param {AbortSignal} [signal] 中止浏览器等待，不撤回本地退出或令牌撤销。
   * @returns {Promise<Readonly<{revocationConfirmed:boolean,browserLogoutConfirmed:boolean}>>}
   * 两项独立回执，不代表全部用户设备退出或任何支付/权益结果。
   */
  async logout(signal) {
    this.#claim();
    let popup;
    let openingError;
    let confirmed = false;
    try {
      try {
        popup = new BrowserPopup(this.#window, this.#postLogout, "logout", this.#timeout,
          signal, () => {}, this.#embedded, this.#issuerOrigin);
      } catch (error) {
        openingError = error;
      }
      const receipt = await this.#clearLogin();
      confirmed = receipt.revocationConfirmed;
      if (!this.#pendingLogout) {
        return Object.freeze({ revocationConfirmed: confirmed, browserLogoutConfirmed: false });
      }
      if (openingError) throw openingError;
      popup.navigate(this.#pendingLogout);
      const callback = await popup.response;
      if (popup.cancelled) throw new SccOidcError(popup.cancelled);
      this.#session.completeLogout(callback);
      this.#pendingLogout = undefined;
      return Object.freeze({ revocationConfirmed: confirmed, browserLogoutConfirmed: true });
    } catch (error) {
      throw new SccOidcError(popup?.cancelled ?? (error instanceof SccOidcError
        ? error.code : "OIDC_BROWSER_LOGOUT_FAILED"), confirmed);
    } finally {
      popup?.dispose();
      this.#busy = false;
    }
  }

  /** 只重试已知凭据的幂等撤销；不打开弹窗、不推定浏览器或未知授权已经退出。 */
  retryRevocation() {
    return this.#session.retryRevocation();
  }

  /** 清空唯一认证会话，同时保留尚未消费的标准退出请求以便用户重试。 */
  async #clearLogin() {
    const receipt = await this.#session.logout();
    if (receipt.endSessionUrl) this.#pendingLogout = receipt.endSessionUrl;
    return receipt;
  }

  /** 串行化用户交互；第二次点击不能取消或取代原授权、退出流程。 */
  #claim() {
    if (this.#busy) throw new SccOidcError("OIDC_SESSION_BUSY");
    this.#busy = true;
  }
}
