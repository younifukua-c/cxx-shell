import { SccApiError } from "./errors.js";

/** 固定协议上限，不能由服务器放宽。 */
const LIMITS = Object.freeze({ keys: 16, targets: 32, jwks: 65535, jws: 65535,
  response: 96 * 1024, payload: 48000, file: 8n * 1024n * 1024n * 1024n,
  integer: 9223372036854775807n });
const PUBLIC_ID = /^[0-9A-HJKMNP-TV-Z]{26}$/;
const CODE = /^[A-Za-z0-9._-]{1,64}$/;
const PLATFORM = /^[a-z0-9_-]{1,32}$/;
const VERIFIERS = new WeakSet();
const PUBLICATION = ["publicationNo", "productCode", "versionCode", "revisionNo", "sequenceNo", "publishedAt", "signedManifest"];
const TARGET = ["targetNo", "artifactNo", "artifactCode", "platformCode", "architectureCode", "minimumSequenceNo", "byteLength", "sha256"];

/** 要求完整且无未知字段，不接受数组或隐式类型转换。 */
function fields(value, expected) {
  if (!value || typeof value !== "object" || Array.isArray(value)
      || Object.keys(value).length !== expected.length
      || expected.some(name => !Object.hasOwn(value, name))) throw new Error("invalid");
}

/** 在await前固定调用者传入的数据，不让并发修改改变已验证结果。 */
function snapshot(value, maximum) {
  const json = JSON.stringify(value);
  if (typeof json !== "string" || json.length > maximum) throw new Error("invalid");
  return JSON.parse(json);
}

/** 精确解析规范整数，不经Number或浮点计算。 */
function number(value, zero) {
  if (typeof value !== "string" || !(zero ? /^(0|[1-9][0-9]{0,18})$/ : /^[1-9][0-9]{0,18}$/).test(value))
    throw new Error("invalid");
  const result = BigInt(value);
  if (result > LIMITS.integer) throw new Error("invalid");
  return result;
}

/** 验证协议代码。 */
function match(value, pattern) {
  if (typeof value !== "string" || !pattern.test(value)) throw new Error("invalid");
}

/** 检查UTC日期合法性，保留原始微秒字符串而不四舍五入。 */
function timestamp(value) {
  match(value, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/);
  const time = new Date(value);
  if (!Number.isFinite(time.getTime()) || time.toISOString().slice(0, 19) !== value.slice(0, 19))
    throw new Error("invalid");
}

/** 检查所有签名文件的完整协议及兼容范围。 */
function validateTarget(target, sequence) {
  fields(target, TARGET);
  match(target.targetNo, PUBLIC_ID);
  match(target.artifactNo, PUBLIC_ID);
  match(target.artifactCode, CODE);
  match(target.platformCode, PLATFORM);
  match(target.architectureCode, PLATFORM);
  match(target.sha256, /^[0-9a-f]{64}$/);
  if (number(target.minimumSequenceNo, true) >= sequence
      || number(target.byteLength, false) > LIMITS.file) throw new Error("invalid");
}

/**
 * 使用jose和软件预置的RFC7638指纹建立不可变信任快照。
 * @param {{jwks:object, pinnedThumbprints:readonly string[]}} options 候选JWKS及通过可信软件发布渠道预置的指纹，不能用本次HTTP响应自动生成指纹。
 * @returns {Promise<{verify:Function}>} 本地验签器；不跟随jku、x5u或内嵌公钥。
 */
export async function createSoftwareUpdateVerifier({ jwks, pinnedThumbprints }) {
  let jose;
  let trusted;
  try {
    const keys = snapshot(jwks, LIMITS.jwks);
    fields(keys, ["keys"]);
    if (!Array.isArray(keys.keys) || keys.keys.length < 1 || keys.keys.length > LIMITS.keys
        || !Array.isArray(pinnedThumbprints) || pinnedThumbprints.length < 1
        || pinnedThumbprints.length > LIMITS.keys) throw new Error("invalid");
    const pins = new Set(pinnedThumbprints);
    for (const pin of pins) match(pin, /^[A-Za-z0-9_-]{43}$/);
    jose = await import("jose");
    const identifiers = new Set();
    trusted = new Map();
    for (const jwk of keys.keys) {
      if (!jwk || typeof jwk !== "object" || Array.isArray(jwk)
          || Object.keys(jwk).some(name => !["kid", "kty", "alg", "use", "n", "e"].includes(name))
          || jwk.kty !== "RSA" || jwk.alg !== undefined && jwk.alg !== "RS256"
          || jwk.use !== undefined && jwk.use !== "sig") throw new Error("invalid");
      match(jwk.kid, /^[A-Za-z0-9._-]{1,100}$/);
      match(jwk.n, /^[A-Za-z0-9_-]{342,1366}$/);
      match(jwk.e, /^[A-Za-z0-9_-]{1,16}$/);
      if (identifiers.has(jwk.kid)) throw new Error("invalid");
      identifiers.add(jwk.kid);
      const key = await jose.importJWK(jwk, "RS256");
      if (key.type !== "public" || key.algorithm.modulusLength < 2048
          || key.algorithm.modulusLength > 8192) throw new Error("invalid");
      const thumbprint = await jose.calculateJwkThumbprint(jwk);
      if (pins.has(thumbprint)) trusted.set(jwk.kid, { key, thumbprint });
    }
    if (!trusted.size) throw new Error("invalid");
  } catch {
    throw new TypeError("更新公钥与预置信任指纹不匹配或配置无效");
  }
  const verifier = Object.freeze({
    /**
     * 验证中央响应与本机软件环境，不把签名当下载资格。
     * @param {object} response 中央更新JSON响应。
     * @param {{productCode:string,platformCode:string,architectureCode:string,installedSequenceNo:string}} query 本软件固定身份和已安装序号。
     * @returns {Promise<object|null>} 已核验更新；无更新为null，不证明文件字节已经核验。
     */
    async verify(response, query) {
      try {
        const value = snapshot(response, LIMITS.response);
        const expected = snapshot(query, LIMITS.response);
        fields(expected, ["productCode", "platformCode", "architectureCode", "installedSequenceNo"]);
        match(expected.productCode, CODE);
        match(expected.platformCode, PLATFORM);
        match(expected.architectureCode, PLATFORM);
        const installed = number(expected.installedSequenceNo, true);
        fields(value, ["publication", "target"]);
        if (value.publication === null && value.target === null) return null;
        const { publication, target: selected } = value;
        fields(publication, PUBLICATION);
        fields(selected, TARGET);
        const signed = publication.signedManifest;
        if (typeof signed !== "string" || signed.length > LIMITS.jws) throw new Error("invalid");
        const header = jose.decodeProtectedHeader(signed);
        fields(header, ["alg", "typ", "kid"]);
        if (header.alg !== "RS256" || header.typ !== "scc-software-update+jws") throw new Error("invalid");
        const signer = trusted.get(header.kid);
        if (!signer) throw new Error("invalid");
        const { payload } = await jose.compactVerify(signed, signer.key, { algorithms: ["RS256"] });
        if (payload.byteLength > LIMITS.payload) throw new Error("invalid");
        const manifest = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(payload));
        fields(manifest, ["formatVersion", "publicationNo", "productCode", "versionCode", "revisionNo", "sequenceNo", "publishedAt", "targets"]);
        if (manifest.formatVersion !== 1
            || PUBLICATION.some(name => name !== "signedManifest" && publication[name] !== manifest[name]))
          throw new Error("invalid");
        match(manifest.publicationNo, PUBLIC_ID);
        match(manifest.revisionNo, PUBLIC_ID);
        match(manifest.versionCode, /^[A-Za-z0-9][A-Za-z0-9._+\-]{0,63}$/);
        timestamp(manifest.publishedAt);
        if (manifest.productCode !== expected.productCode) throw new Error("invalid");
        const sequence = number(manifest.sequenceNo, false);
        if (sequence <= installed || !Array.isArray(manifest.targets)
            || !manifest.targets.length || manifest.targets.length > LIMITS.targets) throw new Error("invalid");
        const slots = new Set();
        const ids = new Set();
        let matched = false;
        for (const target of manifest.targets) {
          validateTarget(target, sequence);
          const slot = target.platformCode + ":" + target.architectureCode;
          if (slots.has(slot) || ids.has(target.targetNo)) throw new Error("invalid");
          slots.add(slot);
          ids.add(target.targetNo);
          if (TARGET.every(name => target[name] === selected[name])) matched = true;
        }
        if (!matched || selected.platformCode !== expected.platformCode
            || selected.architectureCode !== expected.architectureCode
            || number(selected.minimumSequenceNo, true) > installed) throw new Error("invalid");
        const { targets, formatVersion, ...details } = manifest;
        return Object.freeze({ ...details, signedManifest: signed,
          signingKeyThumbprint: signer.thumbprint, target: Object.freeze({ ...selected }) });
      } catch {
        throw new SccApiError({ status: 502, code: "INVALID_SOFTWARE_UPDATE", detail: "软件更新响应未通过验证" });
      }
    }
  });
  VERIFIERS.add(verifier);
  return verifier;
}

/** 防止误传未建立信任根的普通回调，不能代替宿主自身代码安全。 */
export function requireSoftwareUpdateVerifier(verifier) {
  if (!VERIFIERS.has(verifier)) throw new TypeError("必须使用createSoftwareUpdateVerifier创建验签器");
}

/** 下载回执不能改变已验签文件，过期回执必须重新由宿主决定下载意图。 */
export function validateSoftwareDownloadGrant(value, update) {
  try {
    const grant = snapshot(value, LIMITS.response);
    fields(grant, ["grantNo", "productCode", "publicationNo", "targetNo", "artifactNo", "byteLength", "sha256", "expiresAt"]);
    match(grant.grantNo, PUBLIC_ID);
    timestamp(grant.expiresAt);
    if (grant.productCode !== update.productCode || grant.publicationNo !== update.publicationNo
        || ["targetNo", "artifactNo", "byteLength", "sha256"].some(key => grant[key] !== update.target[key])
        || Date.parse(grant.expiresAt) <= Date.now()) throw new Error("invalid");
    return Object.freeze(grant);
  } catch {
    throw new SccApiError({ status: 502, code: "INVALID_DOWNLOAD_GRANT", detail: "下载回执与可信更新不匹配或已过期" });
  }
}
