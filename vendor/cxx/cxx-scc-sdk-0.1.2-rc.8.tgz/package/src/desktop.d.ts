import type { SccClient } from './index.js';
import type { SccOidcSession } from './oidc.js';

/** 宿主登记的独立应用；基础设施标识只由受信任宿主提供。 */
export interface DesktopApplication {
  id: string;
  name: string;
  productCode?: string | null;
  external?: boolean;
  infrastructure?: boolean;
  demo?: boolean;
}
/** 非秘密的固定认证及官网地址，不支持客户端私钥。 */
export interface DesktopIdentityConfiguration {
  issuer: string;
  clientId: string;
  redirectUri: string;
  postLogoutRedirectUri?: string;
  websiteOrigin: string;
  /** 显式请求管理员开发scope；真实管理员身份和客户端范围仍由中央核验。 */
  requestDevelopmentAccess?: boolean;
}
/** 可信宿主完成标准浏览器授权；SDK继续校验回调、PKCE、nonce和签名。 */
export interface DesktopAuthorizationRequest {
  url: string;
  issuer: string;
  redirectUri: string;
  signal?: AbortSignal;
  title?: string;
}
/** 桌面实时资格摘要，不是离线授权票据。 */
export interface DesktopApplicationDecision {
  applicationId: string;
  allowed: boolean;
  reason: string;
  evaluatedAt: string;
  validUntil: string | null;
}
/** 只在宿主消费的中心适配器，不包含任何UI、Electron或文件系统实现。 */
export declare function createSccAccountProvider(options: {
  configuration: DesktopIdentityConfiguration;
  listApplications(): readonly DesktopApplication[];
  authorize(request: DesktopAuthorizationRequest): Promise<string>;
  openStore(url: string): Promise<void>;
  onChanged?: () => void;
  loadSdk?: () => Promise<[{SccClient: typeof SccClient}, {SccOidcSession: typeof SccOidcSession}]>;
}): {
  check(applicationIds: readonly string[], signal?: AbortSignal): Promise<DesktopApplicationDecision[]>;
  snapshot(): {
    identity: {subject: string; displayName: string} | null;
    signOutPending: boolean;
    software: {applicationId: string; name: string; mode: 'FREE' | 'SUBSCRIPTION' | 'UNAVAILABLE'; allowed: boolean; reason: string; planName?: string; accessKind?: 'DEVELOPMENT'; startsAt?: string; expiresAt?: string}[];
  };
  signIn(signal?: AbortSignal): Promise<void>;
  signOut(): Promise<void>;
  openStore(applicationId?: string): Promise<void>;
  openRegistration(): Promise<void>;
  destroy(): Promise<void>;
};
