import { SccApiError } from './errors.js';

const MAX_SOFTWARE = 200;
const MAX_DEVELOPMENT_ACCESS_MS = 30000;
const CODE = /^[A-Za-z0-9._-]{1,64}$/;
const MAX_PLAN_NAME = 128;

/** 展示摘要可缺省或已过期；损坏时省略，绝不据此修改授权结果。 */
function subscriptionSummary(item) {
  if (item.mode !== 'SUBSCRIPTION' || !['ALLOWED', 'SUBSCRIPTION_NOT_ACTIVE', 'OUTSIDE_ACCESS_PERIOD'].includes(item.reason)) return undefined;
  const value = item.subscription;
  if (!value || typeof value.planName !== 'string' || !value.planName.trim() || value.planName.length > MAX_PLAN_NAME
      || typeof value.startsAt !== 'string' || typeof value.expiresAt !== 'string'
      || value.startsAt.length > 40 || value.expiresAt.length > 40
      || !Number.isFinite(Date.parse(value.startsAt)) || !Number.isFinite(Date.parse(value.expiresAt))
      || !(Date.parse(value.startsAt) < Date.parse(value.expiresAt))) return undefined;
  return Object.freeze({ planName: value.planName, startsAt: value.startsAt, expiresAt: value.expiresAt });
}

/** 只接收有界软件代码，集合去重且稳定排序，空集合由调用者短路。 */
export function softwareCodes(values) {
  if (!Array.isArray(values) || values.length > MAX_SOFTWARE || values.some(value => typeof value !== 'string' || !CODE.test(value))) {
    throw new TypeError('软件代码须为最多200项的合法代码数组');
  }
  return [...new Set(values)].sort();
}

/** 不将原始响应或凭据写入异常。 */
function invalid() {
  throw new SccApiError({ status: 502, code: 'INVALID_RUNTIME_ACCESS', detail: '软件使用资料暂时无法核对，请重试' });
}

/** 严格核对公开模式，不根据价格存在与否推断收费。 */
export function runtimePolicies(value, requested) {
  if (!Array.isArray(value) || value.length > requested.length) invalid();
  const seen = new Set();
  return value.map(item => {
    if (!item || !requested.includes(item.productCode) || seen.has(item.productCode)
        || typeof item.name !== 'string' || !item.name || item.name.length > 256
        || !['FREE', 'SUBSCRIPTION'].includes(item.mode)
        || typeof item.version !== 'string' || !/^(?:-1|0|[1-9][0-9]{0,18})$/.test(item.version)) invalid();
    seen.add(item.productCode);
    return Object.freeze({ productCode: item.productCode, name: item.name, mode: item.mode, version: item.version });
  });
}

/** 实时响应须覆盖全部目标并保持时间及允许原因一致，不作为离线许可。 */
export function runtimeDecisions(value, requested) {
  if (!Array.isArray(value) || value.length !== requested.length) invalid();
  const policies = runtimePolicies(value.map(item => ({ ...item,
    mode: item?.mode === null && item.allowed === true && item.reason === 'ADMINISTRATOR_DEVELOPMENT' ? 'FREE' : item?.mode,
    version: '0' })), requested);
  return value.map((item, index) => {
    if (typeof item.allowed !== 'boolean' || typeof item.reason !== 'string' || !item.reason
        || typeof item.evaluatedAt !== 'string' || !Number.isFinite(Date.parse(item.evaluatedAt))) invalid();
    const development = item.allowed && item.reason === 'ADMINISTRATOR_DEVELOPMENT';
    if (development && (typeof item.validUntil !== 'string'
        || !(Date.parse(item.validUntil) > Date.parse(item.evaluatedAt))
        || Date.parse(item.validUntil) - Date.parse(item.evaluatedAt) > MAX_DEVELOPMENT_ACCESS_MS)) invalid();
    if (!development && item.mode === 'FREE' && item.allowed && (item.reason !== 'FREE' || item.validUntil !== null)) invalid();
    if (!development && item.mode === 'SUBSCRIPTION' && item.allowed && (item.reason !== 'ALLOWED'
        || typeof item.validUntil !== 'string' || !(Date.parse(item.validUntil) > Date.parse(item.evaluatedAt)))) invalid();
    if (!item.allowed && (['FREE', 'ALLOWED', 'ADMINISTRATOR_DEVELOPMENT'].includes(item.reason) || item.validUntil !== null)) invalid();
    const { version: _version, ...policy } = policies[index];
    const subscription = subscriptionSummary(item);
    return Object.freeze({ ...policy, mode: item.mode, allowed: item.allowed, reason: item.reason,
      evaluatedAt: item.evaluatedAt, validUntil: item.validUntil, ...(subscription ? { subscription } : {}) });
  });
}
