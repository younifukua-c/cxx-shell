/** OIDC 单次响应上限；同时约束发现文档、JWKS 和令牌响应。 */
const MAX_RESPONSE_BYTES = 256 * 1024;

/** 普通业务JSON响应上限，不用于安装包等流式二进制下载。 */
const MAX_API_RESPONSE_BYTES = 256 * 1024;

/** 对网络和读取均施加中止边界，不依赖宿主的自定义 Fetch 是否及时处理信号。 */
export async function abortable(operation, signal) {
  let onAbort;
  const cancelled = new Promise((_, reject) => {
    onAbort = () => reject(new Error("OIDC_REQUEST_ABORTED"));
    signal.addEventListener("abort", onAbort, { once: true });
    if (signal.aborted) onAbort();
  });
  try {
    return await Promise.race([operation, cancelled]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}

/**
 * 验证部署时信任的 HTTPS 地址；HTTP 仅允许显式开启的本机回环联调。
 * @param {string} value 部署配置地址，不接受来自登录回调的动态 issuer。
 * @param {boolean} allowLoopbackHttp 是否允许回环 HTTP。
 * @returns {URL} 无凭据、query 和 fragment 的地址。
 */
export function secureUrl(value, allowLoopbackHttp) {
  const url = new URL(value);
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (url.username || url.password || url.search || url.hash
      || (url.protocol !== "https:"
        && !(allowLoopbackHttp && loopback && url.protocol === "http:"))) {
    throw new TypeError("OIDC 地址必须使用 HTTPS；本机 HTTP 必须显式开启");
  }
  return url;
}

/**
 * 创建无 Cookie、无重试、无重定向且有体积和总读取超时限制的认证传输。
 * @param {URL} issuer 固定可信 issuer；协议端点必须同源。
 * @param {Function} fetchImpl 宿主可信的 Fetch 实现，禁止记录认证报文。
 * @param {number} timeoutMs 从发起请求到读完响应的最大毫秒数。
 * @returns {Function} oauth4webapi 专用 Fetch 实现。
 */
export function boundedOidcFetch(issuer, fetchImpl, timeoutMs) {
  return boundedFetch(issuer, fetchImpl, timeoutMs, false, MAX_RESPONSE_BYTES);
}

/** 更新查询复用同源、禁跳转、有界读取与总超时机制，仅允许其查询字符串。 */
export function boundedUpdateFetch(issuer, fetchImpl, timeoutMs) {
  return boundedFetch(issuer, fetchImpl, timeoutMs, true, 96 * 1024);
}

/** 普通业务复用同源、禁跳转、有界读取；允许业务查询字符串，不允许Cookie或引用来源。 */
export function boundedApiFetch(issuer, fetchImpl, timeoutMs) {
  return boundedFetch(issuer, fetchImpl, timeoutMs, true, MAX_API_RESPONSE_BYTES);
}

/** 共用网络读取实现；OIDC端点继续禁止query，不因新增更新查询而放宽。 */
function boundedFetch(issuer, fetchImpl, timeoutMs, allowQuery, maximumBytes) {
  return async (input, init = {}) => {
    const target = new URL(String(input));
    const checked = new URL(target.href);
    if (allowQuery) checked.search = "";
    secureUrl(checked.href, issuer.protocol === "http:");
    if (target.origin !== issuer.origin) throw new Error("OIDC_ENDPOINT_REJECTED");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const onAbort = () => controller.abort();
    init.signal?.addEventListener("abort", onAbort, { once: true });
    if (init.signal?.aborted) controller.abort();
    let reader;
    try {
      const pending = Promise.resolve().then(() => fetchImpl(target.href, {
        ...init, redirect: "manual", credentials: "omit", cache: "no-store",
        referrerPolicy: "no-referrer", signal: controller.signal
      })).then(response => {
        if (controller.signal.aborted) {
          response.body?.cancel().catch(() => {});
          throw new Error("OIDC_REQUEST_ABORTED");
        }
        return response;
      });
      const response = await abortable(pending, controller.signal);
      reader = response.body?.getReader();
      if (response.redirected || (response.url && response.url !== target.href)
          || response.status < 200 || response.status >= 300 && response.status < 400) {
        throw new Error("OIDC_REDIRECT_REJECTED");
      }
      const length = response.headers.get("content-length");
      if (length !== null && (!/^\d+$/.test(length) || Number(length) > maximumBytes)) {
        throw new Error("OIDC_RESPONSE_TOO_LARGE");
      }
      const chunks = [];
      let size = 0;
      if (reader) {
        while (true) {
          const { done, value } = await abortable(reader.read(), controller.signal);
          if (done) break;
          size += value.byteLength;
          if (size > maximumBytes) throw new Error("OIDC_RESPONSE_TOO_LARGE");
          chunks.push(value);
        }
      }
      if (controller.signal.aborted) throw new Error("OIDC_REQUEST_ABORTED");
      const bytes = new Uint8Array(size);
      let offset = 0;
      for (const chunk of chunks) {
        bytes.set(chunk, offset);
        offset += chunk.byteLength;
      }
      return new Response(size ? bytes : null, {
        status: response.status, statusText: response.statusText, headers: response.headers
      });
    } finally {
      clearTimeout(timer);
      controller.abort();
      init.signal?.removeEventListener("abort", onAbort);
      if (reader) {
        reader.cancel().catch(() => {});
        reader.releaseLock();
      }
    }
  };
}
