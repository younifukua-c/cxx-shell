/** 支付操作只校验目标及协议，不在客户端推算资金、退款或权益。 */
const PAYMENT_STATUSES = new Set(["CREATED", "PENDING", "AUTHORIZED", "SUCCEEDED", "FAILED", "CLOSED"]);
const ORDER_STATUSES = new Set(["OPEN", "CLOSED", "CANCELLED", "EXPIRED"]);
const CANCELLATION_STATUSES = new Set(["CANCELLED", "PAYMENT_RECEIVED", "OTHER_PAYMENT_UNRESOLVED"]);
const QUERY_STATUSES = new Set(["WAITING", "SUCCEEDED", "CLOSED_UNRESOLVED", "NOT_FOUND"]);

/** 拒绝错误协议，不回显请求参数或中心原文。 */
function invalid() { throw new TypeError("支付请求或中央响应无效"); }

/** 在获取凭据和发起请求前验证原支付编号，拒绝隐式转换和尾部换行。 */
export function paymentNumber(value) {
  return typeof value === "string" && /^[0-9A-HJKMNP-TV-Z]{26}(?![\s\S])/.test(value) ? value : invalid();
}

/** 核对响应对象和原支付目标，拒绝串单。 */
function matchingPayment(value, requested) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid();
  const actual = paymentNumber(value.paymentNo);
  return actual === requested ? actual : invalid();
}

/** 未知状态不能默认映射为成功。 */
function status(value, allowed) { return typeof value === "string" && allowed.has(value) ? value : invalid(); }

/** 核对取消结果；同一订单的另一支付收款时，本支付可以尚未收款。 */
export function paymentCancellation(value, requested) {
  const paymentNo = matchingPayment(value, requested);
  const orderNo = paymentNumber(value.orderNo);
  const cancellationStatus = status(value.cancellationStatus, CANCELLATION_STATUSES);
  const paymentStatus = status(value.paymentStatus, PAYMENT_STATUSES);
  const orderStatus = status(value.orderStatus, ORDER_STATUSES);
  if (cancellationStatus === "CANCELLED" && (paymentStatus !== "CLOSED" || orderStatus !== "CANCELLED")) invalid();
  if (paymentStatus === "SUCCEEDED" && cancellationStatus !== "PAYMENT_RECEIVED") invalid();
  return Object.freeze({ paymentNo, orderNo, cancellationStatus, paymentStatus, orderStatus });
}

/** 保留渠道观察和中心事实；先前观察不得抹去并发收款。 */
export function paymentReconciliation(value, requested) {
  const paymentNo = matchingPayment(value, requested);
  const orderNo = paymentNumber(value.orderNo);
  const queryStatus = status(value.queryStatus, QUERY_STATUSES);
  const paymentStatus = status(value.paymentStatus, PAYMENT_STATUSES);
  if (queryStatus === "SUCCEEDED" && paymentStatus !== "SUCCEEDED") invalid();
  return Object.freeze({ paymentNo, orderNo, queryStatus, paymentStatus });
}
