import { apiProblemError, SccApiError } from "./errors.js";
import { abortable, boundedApiFetch, boundedUpdateFetch } from "./oidc-transport.js";
import { requireSoftwareUpdateVerifier } from "./software-update.js";
import { pointBalance, pointLedgerPage, pointPageQuery } from "./points.js";
import { upgradeTarget, upgradeRequest, upgradeQuote, upgradeCheckoutResult } from "./upgrades.js";
import { paymentNumber, paymentCancellation, paymentReconciliation } from "./payment-operations.js";
import { orderNumber, orderResult } from "./orders.js";
import { softwareCodes, runtimePolicies, runtimeDecisions } from './runtime-access.js';

const RETRYABLE_STATUS = new Set([429, 502, 503, 504]);
/** 自动等待预算；服务端要求更长等待时返回原错误，不缩短等待。 */
const MAXIMUM_RETRY_SECONDS = 5;
/** 限制整秒提示的解析长度；日期、重复或异常提示交由调用方处理原错误。 */
const MAXIMUM_RETRY_AFTER_LENGTH = 64;

/**
 * 计算可自动等待的整秒提示，缺省一秒；不猜测HTTP日期或截断任意长数字。
 * @param {Headers} headers 原响应头。
 * @returns {number|null} 等待毫秒数，null表示立即返回原HTTP错误而非自动重试。
 */
function retryDelay(headers) {
  const value = headers.get("Retry-After") ?? "1";
  if (value.length > MAXIMUM_RETRY_AFTER_LENGTH || !/^[0-9]+$/.test(value)) return null;
  const seconds = Number(value);
  return Number.isSafeInteger(seconds) && seconds <= MAXIMUM_RETRY_SECONDS ? seconds * 1000 : null;
}
/** 提供者或单次完整HTTP交换的最大等待时间，禁止无限等待。 */
const MAXIMUM_TIMEOUT_MS = 5 * 60 * 1000;

/** 传输未完成时不回显宿主错误；写入可能已生效，不能据此换键重付。 */
function requestFailure() {
  return new SccApiError({ status: 502, code: "SDK_REQUEST_FAILED",
    detail: "请求未完成；写入结果可能未知，请保留原请求与幂等键" });
}

/**
 * 拒绝远程明文中控地址，只为本机联调保留 HTTP。
 * @param {URL} url 中控根地址。
 * @returns {void}
 */
function requireSecureEndpoint(url) {
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (url.protocol !== "https:" && !(url.protocol === "http:" && loopback)) {
    throw new TypeError("baseUrl 必须使用 HTTPS，本机回环联调除外");
  }
}

/**
 * 按单调时钟等待完整时长，提前唤醒时补足剩余等待，不受系统时间调整影响。
 * @param {number} milliseconds 等待毫秒数。
 * @returns {Promise<void>} 等待完成。
 */
async function delay(milliseconds) {
  const deadline = performance.now() + milliseconds;
  let remaining = milliseconds;
  do {
    await new Promise((resolve) => setTimeout(resolve, Math.ceil(remaining)));
    remaining = deadline - performance.now();
  } while (remaining > 0);
}

/**
 * 统一订阅中控 JavaScript/TypeScript 用户 API 客户端。
 */
export class SccClient {
  /**
   * @param {{baseUrl:string, accessTokenProvider?:()=>string|Promise<string>, fetchImpl?:typeof fetch, timeoutMs?:number, maxRetries?:number}} options 客户端配置；仅公开报价可省略令牌提供者。
   */
  constructor({ baseUrl, accessTokenProvider, fetchImpl = globalThis.fetch, timeoutMs = 10000, maxRetries = 2 }) {
    const parsed = new URL(baseUrl);
    if (!parsed.origin || parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new TypeError("baseUrl 必须是无凭据、query 和 fragment 的绝对地址");
    }
    requireSecureEndpoint(parsed);
    if (accessTokenProvider !== undefined && typeof accessTokenProvider !== "function")
      throw new TypeError("accessTokenProvider 必须是函数");
    if (typeof fetchImpl !== "function") throw new TypeError("fetchImpl 必须是函数");
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > MAXIMUM_TIMEOUT_MS)
      throw new RangeError("timeoutMs 必须为1至300000的整数");
    if (!Number.isSafeInteger(maxRetries) || maxRetries < 0 || maxRetries > 3)
      throw new RangeError("maxRetries 必须为0至3的整数");
    /** @private */ this.baseUrl = parsed.origin + parsed.pathname.replace(/\/+$/, "");
    /** @private */ this.accessTokenProvider = accessTokenProvider;
    /** @private */ this.fetchImpl = fetchImpl;
    /** @private */ this.timeoutMs = timeoutMs;
    /** @private */ this.maxRetries = maxRetries;
  }

  /**
   * 创建同一写意图在重试期间保持不变的高熵幂等键。
   * @returns {string} UUID 幂等键。
   */
  static newIdempotencyKey() {
    return globalThis.crypto.randomUUID();
  }

  /**
   * 实时读取本人中心通用积分，需单独授予points.read；不缓存或开户。
   * @returns {Promise<import('./index.js').PointBalanceResult>} 全部数量和版本为精确字符串。
   */
  async getPointBalance() {
    return pointBalance(await this.#request("GET", "/api/v1/points/programs/CENTER_POINTS/balance", undefined, undefined, true));
  }

  /**
   * 读取本人流水，不允许指定其他账户或发放积分。
   * @param {{limit?:number,cursor?:string|null}} options 页大小1至100，默认20，cursor原样传回上一页结果。
   * @returns {Promise<import('./index.js').PointLedgerPageResult>} 不可变流水页。
   */
  async getPointLedger({ limit = 20, cursor = null } = {}) {
    const query = pointPageQuery(limit, cursor);
    return pointLedgerPage(await this.#request("GET", `/api/v1/points/programs/CENTER_POINTS/ledger?${query}`, undefined, undefined, true), limit);
  }

  /**
   * 查询登录前也可展示的服务端可信报价和试用天数。
   * @param {{productCode:string, planCode:string, priceCode:string}} request 报价代码。
   * @returns {Promise<object>} 当前可售报价。
   */
  async getOffer({ productCode, planCode, priceCode }) {
    const path = `/api/v1/catalog/products/${encodeURIComponent(productCode)}`
      + `/plans/${encodeURIComponent(planCode)}/offers/${encodeURIComponent(priceCode)}`;
    return this.#publicQuery(path);
  }

  /** 批量读取已发布软件的独立使用模式，不取令牌、不要求先配置价格。 */
  async getSoftwareUsagePolicies(productCodes) {
    const codes = softwareCodes(productCodes);
    if (!codes.length) return [];
    const query = new URLSearchParams();
    for (const code of codes) query.append('productCodes', code);
    return runtimePolicies(await this.#publicQuery(`/api/v1/catalog/runtime-policies?${query}`), codes);
  }

  /** 批量读取本人的当前软件资格，不在客户端逐软件查订阅。 */
  async getRuntimeSoftwareAccess(productCodes) {
    const codes = softwareCodes(productCodes);
    if (!codes.length) return [];
    const query = new URLSearchParams();
    for (const code of codes) query.append('productCodes', code);
    return runtimeDecisions(await this.#request('GET', `/api/v1/me/software-access?${query}`), codes);
  }

  /** 读取服务端核验的本人名称及账户，不暴露密码和联系方式。 */
  async getCurrentUser() {
    const value = await this.#request('GET', '/api/v1/me');
    if (!value || !/^[0-9A-HJKMNP-TV-Z]{26}$/.test(value.subjectId || '')
        || !/^[0-9A-HJKMNP-TV-Z]{26}$/.test(value.accountId || '')
        || typeof value.displayName !== 'string' || !value.displayName || value.displayName.length > 256) {
      throw new SccApiError({ status: 502, code: 'INVALID_CURRENT_USER', detail: '账户资料暂时无法核对，请重试' });
    }
    return { subjectId: value.subjectId, accountId: value.accountId, displayName: value.displayName, status: value.status, zoneId: value.zoneId };
  }

  /** 无身份的公开读取共用有界传输，不重试、不附带Cookie或Bearer。 */
  async #publicQuery(path) {
    let response;
    try {
      const fetcher = boundedApiFetch(new URL(this.baseUrl), this.fetchImpl, this.timeoutMs);
      response = await fetcher(this.baseUrl + path, {
        method: "GET",
        headers: { Accept: "application/json, application/problem+json", "X-Request-Id": globalThis.crypto.randomUUID() }
      });
    } catch {
      throw requestFailure();
    }
    return this.#readResponse(response);
  }

  /**
   * 使用服务端可信价格创建订单和支付意图。
   * @param {{productCode:string, planCode:string, priceCode:string, paymentChannel?:string}} request 价格选择。
   * @param {string} idempotencyKey 同一购买意图的稳定键。
   * @returns {Promise<object>} 结账结果。
   */
  checkout(request, idempotencyKey) {
    return this.#request("POST", "/api/v1/checkout/orders", request, idempotencyKey);
  }

  /**
   * 实时查询本人原订单；不重建订单、不付款，资金与开通状态分别返回。
   * @param {string} orderNo 26位订单公开编号。
   * @returns {Promise<import("./index.js").OrderResult>} 订单快照；使用资格仍由 getProductAccess 决定。
   */
  async getOrder(orderNo) {
    const order = orderNumber(orderNo);
    let response;
    try {
      response = await this.#request("GET", `/api/v1/orders/${order}`, undefined, undefined, true);
    } catch (error) {
      if (error instanceof SyntaxError) throw new TypeError("订单请求或中央响应无效");
      if (error instanceof SccApiError) throw new SccApiError({
        status: error.status, code: error.code, requestId: error.requestId, detail: "订单查询失败"
      });
      throw error;
    }
    return orderResult(response, order);
  }

  /**
   * 查询本人升级报价，不预留价格或权益；金额和版本使用精确字符串。
   * @param {import("./index.js").UpgradeTarget} request 目标软件、套餐及价格。
   * @returns {Promise<import("./index.js").UpgradeQuoteResult>} 中心计算的确认预览。
   */
  async quoteUpgrade(request) {
    const target = upgradeTarget(request);
    const query = new URLSearchParams(target);
    return upgradeQuote(await this.#request("GET", `/api/v1/subscriptions/upgrade-quote?${query}`, undefined, undefined, true), target);
  }

  /**
   * 提交用户明确确认的升级；409不重报价、不重新下单，重试保留原键及请求体。
   * @param {import("./index.js").UpgradeCheckoutRequest} request 版本、来源周期及用户同意的金额上限。
   * @param {string} idempotencyKey 同一升级意图固定使用的幂等键。
   * @returns {Promise<import("./index.js").CheckoutResult>} 中心订单与下一步支付动作，权益仍需查中心。
   */
  async upgradeCheckout(request, idempotencyKey) {
    const confirmed = upgradeRequest(request, idempotencyKey);
    return upgradeCheckoutResult(await this.#request("POST", "/api/v1/subscriptions/upgrade-orders", confirmed, idempotencyKey, true), confirmed);
  }

  /**
   * 取消本人未付款升级，恢复操作始终复用原支付编号，不另建意图。
   * @param {string} paymentNo 原升级支付公开编号；不支持普通购买取消或退款。
   * @returns {Promise<import("./index.js").PaymentCancellationResult>} 中心取消结论及资金、订单状态。
   */
  async cancelUpgradePayment(paymentNo) {
    return this.#paymentOperation(paymentNo, "cancellation");
  }

  /**
   * 查询本人原渠道支付并补记可信收款；权益仍由中心实时判断。
   * @param {string} paymentNo 原购买或升级支付公开编号。
   * @returns {Promise<import("./index.js").PaymentReconciliationResult>} 渠道观察及中心事实；关闭或未找到不等于取消、退款。
   */
  async reconcilePayment(paymentNo) {
    return this.#paymentOperation(paymentNo, "reconciliation");
  }

  /** 支付协议解析失败不携带原始报文；业务错误与网络错误保持原语义。 */
  async #paymentOperation(paymentNo, operation) {
    const payment = paymentNumber(paymentNo);
    let response;
    try {
      response = await this.#request("POST", `/api/v1/payments/${payment}/${operation}`, undefined, undefined, true);
    } catch (error) {
      if (error instanceof SyntaxError) throw new TypeError("支付请求或中央响应无效");
      throw error;
    }
    return operation === "cancellation" ? paymentCancellation(response, payment) : paymentReconciliation(response, payment);
  }

  /**
   * 查询当前用户的活动报价，不在 SDK 计算金额或预约首单资格。
   * @param {{productCode:string,planCode:string,priceCode:string,activityCode:string}} request 目录与活动代码。
   * @returns {Promise<object>} 原价、优惠、应付和下单时需确认的修订。
   */
  quoteDiscount({ productCode, planCode, priceCode, activityCode }) {
    const query = new URLSearchParams({ productCode, planCode, priceCode, activityCode });
    return this.#request("GET", `/api/v1/checkout/quote?${query}`, undefined, undefined);
  }

  /**
   * 实时读取已授权软件当前允许的支付渠道，结账仍由服务端重新校验。
   * @param {string} productCode 软件稳定代码。
   * @returns {Promise<{productCode:string,channels:readonly string[]}>} 不含商户秘密的渠道列表。
   */
  async getPaymentMethods(productCode) {
    const result = await this.#request("GET", `/api/v1/products/${encodeURIComponent(productCode)}/payment-methods`);
    if (result?.productCode !== productCode || !Array.isArray(result.channels)
        || result.channels.some(channel => typeof channel !== "string" || !/^[A-Z0-9_-]{1,32}$/.test(channel))
        || new Set(result.channels).size !== result.channels.length) {
      throw new TypeError("中央支付方式响应无效");
    }
    return Object.freeze({ productCode: result.productCode, channels: Object.freeze([...result.channels]) });
  }

  /**
   * 领取价格配置的账户产品终身一次免费试用。
   * @param {{productCode:string, planCode:string, priceCode:string}} request 试用价格选择。
   * @param {string} idempotencyKey 同一领取意图的稳定键。
   * @returns {Promise<object>} 试用订阅摘要。
   */
  startTrial(request, idempotencyKey) {
    return this.#request("POST", "/api/v1/subscription-trials", request, idempotencyKey);
  }

  /**
   * 使用一次性兑换码激活或延长订阅。
   * @param {string} code 用户输入兑换码。
   * @param {string} idempotencyKey 同一兑换意图的稳定键。
   * @returns {Promise<object>} 兑换后的订阅摘要。
   */
  redeem(code, idempotencyKey) {
    return this.#request("POST", "/api/v1/redemptions", { code }, idempotencyKey);
  }

  /**
   * 查询当前用户拥有的订阅。
   * @param {string} subscriptionNo 对外订阅编号。
   * @returns {Promise<object>} 订阅摘要。
   */
  getSubscription(subscriptionNo) {
    return this.#request("GET", `/api/v1/subscriptions/${encodeURIComponent(subscriptionNo)}`);
  }

  /**
   * 实时查询当前用户的软件使用资格，拒绝矛盾响应且不缓存放行结果。
   * @param {string} productCode 软件稳定代码。
   * @returns {Promise<object>} 中央判定，不是离线许可。
   */
  async getProductAccess(productCode) {
    const result = await this.#request("GET", `/api/v1/products/${encodeURIComponent(productCode)}/access`);
    this.#validateAccessDecision(result, productCode);
    return result;
  }

  /**
   * 实时查询本人功能资格，不缓存放行结果，也不消耗配额。
   * @param {string} productCode 当前客户端已获授权的软件代码。
   * @param {string} featureCode 大小写敏感的功能代码。
   * @returns {Promise<object>} 中央实时判定，不是离线许可。
   */
  async getFeatureAccess(productCode, featureCode) {
    const result = await this.#request("GET", `/api/v1/products/${encodeURIComponent(productCode)}/features/${encodeURIComponent(featureCode)}/access`);
    this.#validateAccessDecision(result, productCode);
    if (result.featureCode !== featureCode || typeof result.featureCode !== "string"
        || !/^[A-Za-z0-9._-]{1,64}$/.test(result.featureCode)) {
      throw new SccApiError({ status: 502, code: "INVALID_ACCESS_DECISION", detail: "中央功能资格响应的目标无效" });
    }
    return result;
  }

  /** 拒绝字段缺失、目标不符或允许状态与有效期互相矛盾的授权响应。 */
  #validateAccessDecision(result, productCode) {
    if (!result || result.productCode !== productCode || typeof result.allowed !== "boolean"
        || typeof result.reason !== "string" || !result.reason
        || result.allowed !== (result.reason === "ALLOWED")
        || typeof result.evaluatedAt !== "string" || !Number.isFinite(Date.parse(result.evaluatedAt))
        || (result.allowed && (typeof result.validUntil !== "string"
          || !(Date.parse(result.validUntil) > Date.parse(result.evaluatedAt))))
        || (!result.allowed && result.validUntil !== null)) {
      throw new SccApiError({ status: 502, code: "INVALID_ACCESS_DECISION", detail: "中央使用资格响应无效" });
    }
  }

  /** 获取候选更新公钥；必须与软件预置指纹匹配，不能直接作为信任根。 */
  getSoftwareUpdateKeys() {
    return this.#updateRequest("/api/v1/software-update-keys");
  }

  /** 申请短期下载回执；回执须与签名元数据匹配，不能单独作为可信文件说明。 */
  issueSoftwareDownloadGrant(productCode, targetNo, idempotencyKey) {
    if (typeof idempotencyKey !== "string" || !idempotencyKey.trim() || idempotencyKey.length > 128)
      throw new TypeError("下载授权需要稳定幂等键");
    return this.#updateRequest(`/api/v1/products/${encodeURIComponent(productCode)}/software-update-targets/${encodeURIComponent(targetNo)}/download-grants`, "POST", idempotencyKey);
  }

  /**
   * 查询并核验本软件更新；不会下载文件或代替中央下载资格检查。
   * @param {object} query 软件、平台、架构和当前安装序号。
   * @param {object} verifier 由createSoftwareUpdateVerifier创建的固定信任验签器。
   * @returns {Promise<object|null>} 已核验的更新元数据；无更新为null。
   */
  async checkSoftwareUpdate(query, verifier) {
    requireSoftwareUpdateVerifier(verifier);
    const expected = { ...query };
    const params = new URLSearchParams({ platformCode: expected.platformCode,
      architectureCode: expected.architectureCode, installedSequenceNo: expected.installedSequenceNo });
    const path = `/api/v1/products/${encodeURIComponent(expected.productCode)}/software-updates?${params}`;
    return verifier.verify(await this.#updateRequest(path), expected);
  }

  /** 将受限读取失败转换为不暴露认证内容的统一异常。 */
  async #updateRequest(path, method = "GET", idempotencyKey) {
    try {
      return await this.#request(method, path, undefined, idempotencyKey, true);
    } catch (error) {
      if (error instanceof SccApiError && error.code !== "SDK_REQUEST_FAILED") throw error;
      throw new SccApiError({ status: 502, code: "UPDATE_REQUEST_FAILED", detail: "更新请求读取失败" });
    }
  }

  /** 有限等待令牌提供者；超时后迟到的令牌不触发请求，不保留提供者异常或秘密。 */
  async #accessToken() {
    if (typeof this.accessTokenProvider !== "function") throw new TypeError("此接口需要配置 accessTokenProvider");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const token = await abortable(Promise.resolve().then(() => this.accessTokenProvider()), controller.signal);
      if (typeof token !== "string" || !token || /[\u0000-\u0020\u007f]/.test(token)) throw requestFailure();
      return token;
    } catch {
      throw requestFailure();
    } finally {
      clearTimeout(timer);
      controller.abort();
    }
  }

  /**
   * 先固定调用时的JSON意图，再获取令牌；首次发送与有限重试复用同一份请求内容。
   * @param {string} method HTTP 方法。
   * @param {string} path API 路径。
   * @param {object|undefined} body 可选 JSON 请求体。
   * @param {string|undefined} idempotencyKey 写请求幂等键。
   * @param {boolean} bounded 是否采用已有的96KiB严格上限；其他请求同样有界，上限256KiB。
   * @returns {Promise<object>} JSON 响应。
   */
  async #request(method, path, body, idempotencyKey, bounded = false) {
    const serialized = body === undefined ? undefined : JSON.stringify(body);
    const token = await this.#accessToken();
    for (let attempt = 0; attempt <= this.maxRetries; attempt += 1) {
      const headers = {
        Accept: "application/json, application/problem+json",
        Authorization: `Bearer ${token}`,
        "X-Request-Id": globalThis.crypto.randomUUID()
      };
      if (serialized !== undefined) headers["Content-Type"] = "application/json";
      if (idempotencyKey) headers["Idempotency-Key"] = idempotencyKey;
      const fetcher = (bounded ? boundedUpdateFetch : boundedApiFetch)(new URL(this.baseUrl), this.fetchImpl, this.timeoutMs);
      let response;
      try {
        response = await fetcher(this.baseUrl + path, { method, headers, body: serialized });
      } catch {
        throw requestFailure();
      }
      if (!response.ok && attempt < this.maxRetries && RETRYABLE_STATUS.has(response.status)) {
        const milliseconds = retryDelay(response.headers);
        if (milliseconds !== null) {
          await delay(milliseconds);
          continue;
        }
      }
      return this.#readResponse(response);
    }
    throw new Error("HTTP 重试循环未返回结果");
  }

  /** 公开报价和用户请求共用响应解析，保留真实HTTP状态，不回显畸形JSON内容。 */
  async #readResponse(response) {
    if (response.ok) {
      try { return await response.json(); }
      catch { throw new SyntaxError("中央响应JSON无效"); }
    }
    let problem;
    try { problem = await response.json(); }
    catch { problem = null; }
    throw apiProblemError(response.status, problem, response.headers.get("X-Request-Id"));
  }
}
