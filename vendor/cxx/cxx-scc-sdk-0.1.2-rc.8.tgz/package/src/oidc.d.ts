/** 公开客户端 OIDC 配置；不接受 client_secret，也不允许动态回调 issuer。 */
export interface SccOidcOptions {
  /** 部署配置的中心 issuer，必须与发现文档完全相同，包括末尾斜杠。 */
  issuer: string;
  /** 中心登记的公开客户端编号。 */
  clientId: string;
  /** 精确登记的 HTTPS 或显式本机 HTTP 回调，不支持 query/fragment/custom scheme。 */
  redirectUri: string;
  /** 包含 openid 的最小 scope 集合，以单空格分隔。 */
  scope: string;
  /** 可选的精确浏览器退出回调；未配置时 logout 只撤销令牌家族。 */
  postLogoutRedirectUri?: string;
  /** 仅用于本机联调，默认 false；绝不允许远程明文 HTTP。 */
  allowLoopbackHttp?: boolean;
  /** 单次认证网络请求到读完响应的最大毫秒数，100–30000，默认 10000。 */
  timeoutMs?: number;
  /** 可信 Fetch 注入；宿主不得记录认证请求或响应，须遵守 AbortSignal。 */
  fetchImpl?: typeof fetch;
}

/** 不包含原始令牌、响应、回调或底层 cause 的稳定错误。 */
export declare class SccOidcError extends Error {
  /** OIDC_CONFIGURATION_REJECTED / SESSION_BUSY / CALLBACK_REJECTED 等固定错误码。 */
  readonly code: string;
  /** 本次已知凭据的中心撤销是否已有成功回执；不代表所有设备已退出。 */
  readonly revocationConfirmed: boolean;
  constructor(code: string, revocationConfirmed?: boolean);
}

/** 单用户、单宿主、仅私有内存的公开客户端认证会话。 */
export declare class SccOidcSession {
  private constructor();
  /** 验证发现元数据、同源 HTTPS 端点、S256 和固定 RS256 算法。 */
  static discover(options: SccOidcOptions): Promise<SccOidcSession>;
  /** 返回授权 URL；宿主需保持存活，通过系统浏览器或受控弹窗完成授权。 */
  beginLogin(options?: {prompt?: 'none'}): Promise<string>;
  /** 一次性消费精确回调，校验签名、issuer、audience、expiry、nonce，返回无凭据摘要。 */
  completeLogin(callbackUrl: string): Promise<Readonly<{
    /** OIDC 用户主体标识，不是可自由指定的业务账户编号。 */
    subject: string;
    /** 实际获准范围，不代表业务对象权限或权益。 */
    scope: string;
    /** 本地保守到期时刻，Unix 毫秒。 */
    expiresAt: number;
  }>>;
  /** 提供短期访问凭据；临期时 single-flight，不重放任何业务请求。 */
  accessToken(): Promise<string>;
  /** 同一会话所有并发刷新共享一次请求；失败仅允许撤销和重新授权。 */
  refresh(): Promise<string>;
  /** 立即清空本地登录、撤销已知家族，返回可选系统浏览器退出地址。 */
  logout(): Promise<Readonly<{
    /** 本次已知家族撤销已有中心回执，且无未决换码或刷新。 */
    revocationConfirmed: boolean;
    /** 可选 OIDC 退出地址，包含 ID Token 提示，禁止记录或持久化。 */
    endSessionUrl: string | null;
  }>>;
  /** 仅重试幂等撤销；不会重用已轮换或结果未知的 Refresh Token。 */
  retryRevocation(): Promise<boolean>;
  /** 为待完成的浏览器退出生成新的一次性事务；替换旧 state，不恢复登录。地址禁止记录或持久化。 */
  beginLogout(): string | null;
  /** 一次性验证退出回调 state；不改变新的登录身份，也不推定撤销成功。 */
  completeLogout(callbackUrl: string): void;
}
