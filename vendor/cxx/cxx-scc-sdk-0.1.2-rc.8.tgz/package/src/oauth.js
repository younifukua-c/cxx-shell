const encoder = new TextEncoder();

/**
 * 拒绝可能泄露授权参数的非 HTTPS 远程 issuer。
 * @param {URL} issuer 中控 issuer。
 * @returns {void}
 */
function requireSecureIssuer(issuer) {
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(issuer.hostname);
  if (issuer.username || issuer.password || issuer.search || issuer.hash
      || (issuer.pathname !== "" && issuer.pathname !== "/")) {
    throw new TypeError("issuer 必须是无凭据、query、fragment 和路径的根地址");
  }
  if (issuer.protocol !== "https:" && !(issuer.protocol === "http:" && loopback)) {
    throw new TypeError("issuer 必须是 HTTPS 根地址，本机回环联调除外");
  }
}

/**
 * 将字节转换为无填充 Base64URL。
 * @param {Uint8Array} bytes 原始字节。
 * @returns {string} Base64URL 文本。
 */
function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

/**
 * 生成密码学安全随机字符串。
 * @returns {string} 高熵 URL-safe 字符串。
 */
function randomValue() {
  const bytes = new Uint8Array(32);
  globalThis.crypto.getRandomValues(bytes);
  return base64Url(bytes);
}

/**
 * 为浏览器、桌面 WebView 外壳生成 OAuth 2.1 PKCE 授权会话。
 * @returns {Promise<{codeVerifier:string, codeChallenge:string, state:string, nonce:string}>} 授权参数。
 */
export async function createPkceSession() {
  const codeVerifier = randomValue();
  const digest = await globalThis.crypto.subtle.digest("SHA-256", encoder.encode(codeVerifier));
  return {
    codeVerifier,
    codeChallenge: base64Url(new Uint8Array(digest)),
    state: randomValue(),
    nonce: randomValue()
  };
}

/**
 * 构造必须由系统浏览器打开的 Authorization Code + PKCE 地址。
 * @param {{issuer:string, clientId:string, redirectUri:string, scope:string, session:{codeChallenge:string,state:string,nonce:string}}} options OAuth 参数。
 * @returns {string} 标准授权地址。
 */
export function buildAuthorizationUrl({ issuer, clientId, redirectUri, scope, session }) {
  const issuerUrl = new URL(issuer);
  requireSecureIssuer(issuerUrl);
  const url = new URL("/oauth2/authorize", issuerUrl);
  url.search = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    scope,
    code_challenge: session.codeChallenge,
    code_challenge_method: "S256",
    state: session.state,
    nonce: session.nonce
  }).toString();
  return url.toString();
}
