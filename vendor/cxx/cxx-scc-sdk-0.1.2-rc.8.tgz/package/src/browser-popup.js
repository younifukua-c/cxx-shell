import { SccOidcError } from "./oidc.js";
import { CALLBACK_MESSAGE, callbackUrl } from "./browser-callback.js";

/** 用户关闭窗口或 COOP 分离的检测间隔，不进行网络轮询。 */
const CLOSED_POLL_MS = 100;

/**
 * 一个受控弹窗的生命周期；仅持有本次协议关联资料，不保存用户或凭据事实。
 * 监听器在跳转前安装，所有结束路径释放监听器、定时器和本对象创建的弹窗。
 */
export class BrowserPopup {
  /** 持有本次授权的顶层宿主窗口。 */
  #window;
  /** 仅由本次用户手势创建的窗口代理。 */
  #popup;
  /** 第一方同源模式的不可交互协议框架；从不展示默认认证页面。 */
  #frame;
  /** 固定 issuer 来源；反代只替换浏览器送达来源，不改变 OIDC 签发者。 */
  #issuerOrigin;
  /** 静态登记的回调地址。 */
  #expected;
  /** 本次流程为登录或退出。 */
  #kind;
  /** 核心协议生成的本次一次性关联值。 */
  #state;
  /** 向宿主交付已筛选回调的完成函数。 */
  #resolve;
  /** 向宿主交付固定取消错误的完成函数。 */
  #reject;
  /** 当前 message 监听器，结束后必须移除。 */
  #listener;
  /** 页面离开时终止本流程的监听器。 */
  #pageHide;
  /** 用户中止本流程的监听器。 */
  #abort;
  /** 可选用户取消信号。 */
  #signal;
  /** 本次交互总期限的定时器句柄。 */
  #timer;
  /** 关闭窗口检测的定时器句柄。 */
  #poll;
  /** 已收到一份回调，后续消息不得再次消费。 */
  #received = false;
  /** 同步使核心登录世代失效的宿主回调。 */
  #onCancel;
  /** 受控回调的 Promise；不输出到日志或其他窗口。 */
  response;
  /** 超时、中止、关闭或导航失败的固定错误码。 */
  cancelled;

  /** 同步打开空白窗口，保留浏览器用户手势；不得先等待发现、PKCE 或网络。 */
  constructor(browserWindow, expected, kind, timeoutMs, signal, onCancel, embedded = false, issuerOrigin = expected.origin) {
    this.#window = browserWindow;
    this.#expected = expected;
    this.#kind = kind;
    this.#signal = signal;
    this.#onCancel = onCancel;
    this.#issuerOrigin = issuerOrigin;
    if (signal?.aborted) throw new SccOidcError("OIDC_BROWSER_CANCELLED");
    try {
      if (embedded) {
        this.#frame = browserWindow.document.createElement('iframe');
        this.#frame.hidden = true;
        this.#frame.title = '同源认证协议';
        this.#frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms');
        browserWindow.document.body.append(this.#frame);
        this.#popup = this.#frame.contentWindow;
      } else {
        this.#popup = browserWindow.open("about:blank", "_blank", "popup,width=520,height=720");
      }
    } catch {
      throw new SccOidcError("OIDC_BROWSER_POPUP_BLOCKED");
    }
    if (!this.#popup) {this.#frame?.remove(); throw new SccOidcError("OIDC_BROWSER_POPUP_BLOCKED");}
    this.response = new Promise((resolve, reject) => { this.#resolve = resolve; this.#reject = reject; });
    // PKCE/撤销仍在等待时，取消可能先发生，避免未处理的 Promise rejection。
    this.response.catch(() => {});
    this.#listener = event => this.#receive(event);
    this.#pageHide = () => this.cancel("OIDC_BROWSER_CANCELLED");
    this.#abort = () => this.cancel("OIDC_BROWSER_CANCELLED");
    try {
      browserWindow.addEventListener("message", this.#listener);
      browserWindow.addEventListener("pagehide", this.#pageHide);
      signal?.addEventListener("abort", this.#abort, { once: true });
      this.#timer = browserWindow.setTimeout(() => this.cancel("OIDC_BROWSER_TIMEOUT"), timeoutMs);
      this.#poll = browserWindow.setInterval(() => {
        try {
          if (this.#popup.closed || (this.#frame && !this.#frame.isConnected)) this.cancel("OIDC_BROWSER_CLOSED");
        } catch {
          this.cancel("OIDC_BROWSER_CLOSED");
        }
      }, CLOSED_POLL_MS);
    } catch {
      this.dispose();
      throw new SccOidcError("OIDC_BROWSER_UNAVAILABLE");
    }
  }

  /** 安装预期 state 后仅导航本对象创建的窗口；地址由核心会话生成。 */
  navigate(value) {
    if (this.cancelled) throw new SccOidcError(this.cancelled);
    const url = new URL(value);
    if (this.#frame) {
      if (url.origin !== this.#issuerOrigin) throw new SccOidcError('OIDC_BROWSER_CONFIGURATION_REJECTED');
      const delivery = new URL(this.#expected.origin);
      url.protocol = delivery.protocol; url.host = delivery.host;
    }
    this.#state = url.searchParams.get("state");
    if (!this.#state) throw new SccOidcError("OIDC_BROWSER_UNAVAILABLE");
    try {
      this.#popup.location.replace(url.href);
    } catch {
      this.cancel("OIDC_BROWSER_NAVIGATION_FAILED");
      throw new SccOidcError(this.cancelled);
    }
  }

  /** 只有精确来源、窗口对象、消息结构和本次 state 都匹配才消费回调。 */
  #receive(event) {
    if (this.cancelled || this.#received || !this.#state
        || event.origin !== this.#expected.origin || event.source !== this.#popup) return;
    try {
      const data = event.data;
      if (!data || typeof data !== "object" || Array.isArray(data)
          || Object.keys(data).length !== 3 || data.type !== CALLBACK_MESSAGE
          || data.kind !== this.#kind || typeof data.url !== "string") return;
      const url = callbackUrl(data.url, this.#expected, this.#kind);
      if (!url || url.searchParams.get("state") !== this.#state) return;
      this.#received = true;
      this.#window.clearInterval(this.#poll);
      this.#resolve(url.href);
    } catch {
      // 无关或畸形消息不能取消仍有效的授权事务。
    }
  }

  /** 立即使本次窗口流程失效；核心会话由宿主同步撤销本地登录世代。 */
  cancel(code) {
    if (this.cancelled) return;
    this.cancelled = code;
    this.#reject(new SccOidcError(code));
    this.#onCancel();
    this.dispose();
  }

  /** 清理本次所有 UI 资源；关闭失败不能变成中心退出成功。 */
  dispose() {
    this.#window.removeEventListener("message", this.#listener);
    this.#window.removeEventListener("pagehide", this.#pageHide);
    this.#signal?.removeEventListener("abort", this.#abort);
    this.#window.clearTimeout(this.#timer);
    this.#window.clearInterval(this.#poll);
    if (this.#frame) this.#frame.remove();
    else try { this.#popup?.close(); } catch { /* 宿主已关闭或 COOP 分离，无权操作其他窗口。 */ }
    this.#state = undefined;
  }
}
