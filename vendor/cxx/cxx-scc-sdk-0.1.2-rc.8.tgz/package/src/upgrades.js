/** 升级协议只核对类型、精度及确认目标，不在客户端执行定价或授权。 */
const MAXIMUM = 9223372036854775807n;
const MAX_SUBSCRIPTION_VERSION = MAXIMUM - 1n;

/** 拒绝错误协议，不暴露响应原文。 */
function invalid() { throw new TypeError("升级请求或中央响应无效"); }
/** 严格匹配完整字符串，拒绝末尾换行和隐式类型转换。 */
function match(value, expression) {
  return typeof value === "string" && new RegExp(`^(?:${expression})(?![\\s\\S])`).test(value) ? value : invalid();
}
/** 保留BIGINT范围内规范非负整数的原始字符串。 */
function integer(value, maximum = MAXIMUM) {
  match(value, "0|[1-9][0-9]{0,18}");
  return BigInt(value) <= maximum ? value : invalid();
}
/** 校验公开编号。 */
function id(value) { return match(value, "[0-9A-HJKMNP-TV-Z]{26}"); }
/** 校验非空协议文本。 */
function text(value) { return typeof value === "string" && value.trim() ? value : invalid(); }
/** 保留明确的null，缺失字段不得冒充空值。 */
function nullableText(value) { return value === null ? null : text(value); }
/** 校验UTC时间，不推导生效规则。 */
function time(value) {
  match(value, "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\\.[0-9]{1,9})?Z");
  return Number.isFinite(Date.parse(value)) ? value : invalid();
}
/** 校验精确金额并复制，避免调用者修改正在提交的确认。 */
function money(value) {
  if (!value) invalid();
  return Object.freeze({ amountMinor: integer(value.amountMinor), currency: match(value.currency, "[A-Z]{3}") });
}
/** 固定升级目标，只允许中心公开代码格式。 */
export function upgradeTarget(value) {
  if (!value) invalid();
  return Object.freeze({ productCode: match(value.productCode, "[A-Za-z0-9._-]{1,64}"),
    targetPlanCode: match(value.targetPlanCode, "[A-Za-z0-9._-]{1,64}"),
    targetPriceCode: match(value.targetPriceCode, "[A-Za-z0-9._-]{1,96}") });
}
/** 固定用户确认，必须在等待Token和网络请求前完成。 */
export function upgradeRequest(value, key) {
  const target = upgradeTarget(value);
  match(key, "[A-Za-z0-9._~-]{1,128}");
  return Object.freeze({ ...target, sourcePeriodNo: id(value.sourcePeriodNo),
    subscriptionVersion: integer(value.subscriptionVersion, MAX_SUBSCRIPTION_VERSION),
    policyVersion: integer(value.policyVersion), maximumPayable: money(value.maximumPayable),
    paymentChannel: match(value.paymentChannel, "[A-Za-z0-9._-]{1,32}") });
}
/** 核对中心响应目标及精确版本，返回不可变报价，不自动确认。 */
export function upgradeQuote(value, target) {
  const policy = value?.policy;
  if (!policy || value.productCode !== target.productCode || policy.productCode !== target.productCode
      || policy.targetPlanCode !== target.targetPlanCode || value.targetPriceCode !== target.targetPriceCode
      || policy.enabled !== true) invalid();
  const targetPrice = money(value.targetPrice);
  const payable = money(value.payable);
  const sourceBasis = value.sourceBasis === null ? null : money(value.sourceBasis);
  if (targetPrice.currency !== payable.currency || (sourceBasis && sourceBasis.currency !== payable.currency)) invalid();
  return Object.freeze({ productCode: target.productCode, subscriptionNo: id(value.subscriptionNo),
    subscriptionVersion: integer(value.subscriptionVersion, MAX_SUBSCRIPTION_VERSION),
    sourcePeriodNo: id(value.sourcePeriodNo), sourcePriceCode: text(value.sourcePriceCode), targetPriceCode: target.targetPriceCode,
    policy: Object.freeze({ productCode: target.productCode, sourcePlanCode: text(policy.sourcePlanCode),
      targetPlanCode: target.targetPlanCode, enabled: true, chargeMode: text(policy.chargeMode),
      priceBasis: nullableText(policy.priceBasis), effectiveMode: text(policy.effectiveMode), termRule: text(policy.termRule),
      version: integer(policy.version), rounding: nullableText(policy.rounding) }),
    sourceBasis, targetPrice, payable, evaluatedAt: time(value.evaluatedAt), sourcePeriodStart: time(value.sourcePeriodStart),
    sourcePeriodEnd: time(value.sourcePeriodEnd), effectiveAt: time(value.effectiveAt), targetPeriodEnd: time(value.targetPeriodEnd) });
}
/** 核对中心结账金额与确认上限；返回动作不代表已授权使用软件。 */
export function upgradeCheckoutResult(value, request) {
  const amount = money(value?.amount);
  if (amount.currency !== request.maximumPayable.currency || BigInt(amount.amountMinor) > BigInt(request.maximumPayable.amountMinor)) invalid();
  return Object.freeze({ orderNo: id(value.orderNo), paymentNo: value.paymentNo === null ? null : id(value.paymentNo), amount,
    orderPaymentStatus: text(value.orderPaymentStatus), fulfillmentStatus: text(value.fulfillmentStatus),
    paymentStatus: nullableText(value.paymentStatus), expiresAt: time(value.expiresAt),
    actionType: text(value.actionType), actionValue: nullableText(value.actionValue) });
}
