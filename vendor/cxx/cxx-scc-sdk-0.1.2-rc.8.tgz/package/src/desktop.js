
/** 中心适配器拥有认证协议和DTO转换；窗口、公共组件及软件业务不持有令牌。 */
export function createSccAccountProvider({ configuration, listApplications, authorize, openStore, onChanged = () => {}, loadSdk = () => Promise.all([import('./index.js'), import('./oidc.js')]) }) {
    let sdk, oidc, identity = null, revision = 0, loginTask, loginController, signOutTask, cleanupTask, revoking, disposed = false;
    const details = new Map();
    const available = () => listApplications().map(item => ({ ...item, productCode: item.productCode || (item.external ? item.id : null) }));

    /** 只保留用于退出的会话；浏览器Cookie尚未退出时也必须提供重试。 */
    function retainCleanup(session, result) {
        if (!result.revocationConfirmed || result.endSessionUrl) revoking = { session, result };
    }

    /** 延迟加载公开SDK，仅服务端发现值与固定配置可以建立认证会话。 */
    async function clients() {
        sdk ||= await loadSdk();
        const [{ SccClient }, { SccOidcSession }] = sdk;
        const publicClient = new SccClient({ baseUrl: configuration.issuer, maxRetries: 0 });
        return { publicClient, SccClient, SccOidcSession };
    }

    /** 匿名读取公开目录，登录后整批核验，管理员开发资格只接受中央裁决。 */
    async function check(ids, signal) {
        if (disposed || signal?.aborted) throw Object.assign(new Error('账户会话已关闭或操作已取消'), { code: 'ACCOUNT_CHANGED' });
        const current = revision;
        const applications = new Map(available().map(item => [item.id, item]));
        const selected = ids.map(id => {
            const item = applications.get(id);
            if (!item) throw Object.assign(new Error('此软件尚未登记，请先在应用中心加入'), { code: 'APPLICATION_UNKNOWN' });
            return item;
        });
        const codes = selected.filter(item => item.productCode).map(item => item.productCode);
        const services = codes.length ? await clients() : null;
        const signedIn = !!(oidc && identity);
        const policies = new Map((codes.length && !signedIn ? await services.publicClient.getSoftwareUsagePolicies(codes) : []).map(item => [item.productCode, item]));
        let decisions = new Map(), currentProfile;
        if (codes.length && signedIn) {
            const active = oidc;
            const business = new services.SccClient({ baseUrl: configuration.issuer, accessTokenProvider: () => active.accessToken(), maxRetries: 0 });
            try {
                const [accessResult, profileResult] = await Promise.allSettled([business.getRuntimeSoftwareAccess(codes), business.getCurrentUser()]);
                if (accessResult.status === 'rejected') throw accessResult.reason;
                if (profileResult.status === 'fulfilled') {
                    if (profileResult.value.subjectId !== identity?.subject) throw Object.assign(new Error('账户已变化，请重新登录后核对资料'), { code: 'ACCOUNT_CHANGED' });
                    currentProfile = profileResult.value;
                } else if (profileResult.reason.status === 401 || profileResult.reason.code === 'OIDC_REAUTHORIZATION_REQUIRED') {
                    throw profileResult.reason;
                }
                // 展示资料暂不可读时保留原名称；实际使用资格始终来自本次中央裁决。
                decisions = new Map(accessResult.value.map(item => [item.productCode, item]));
            }
            catch (error) {
                if (active === oidc && (error.status === 401 || error.code === 'OIDC_REAUTHORIZATION_REQUIRED')) {
                    const ending = { session: active, result: null };
                    revoking = ending;
                    identity = null; oidc = null; revision++; details.clear(); onChanged();
                    cleanupTask = active.logout().then(result => {
                        ending.result = result;
                        if (result.revocationConfirmed && !result.endSessionUrl && revoking === ending) revoking = null;
                        onChanged();
                    });
                    try { await cleanupTask; } finally { cleanupTask = undefined; }
                    throw Object.assign(new Error('登录状态已失效，请先完成退出后重新登录'), { code: 'LOGIN_REQUIRED' });
                }
                throw error;
            }
        }
        if (disposed || signal?.aborted || revision !== current) throw Object.assign(new Error('账户已变化，请重新核对'), { code: 'ACCOUNT_CHANGED' });
        // 名称与同批资格一起发布；通知仍由宿主的可见状态比较发出，避免读取触发刷新循环。
        if (currentProfile) identity = { subject: currentProfile.subjectId, displayName: currentProfile.displayName };
        const evaluatedAt = new Date().toISOString();
        return selected.map(item => {
            const decision = decisions.get(item.productCode);
            const policy = decision?.reason === 'PRODUCT_UNAVAILABLE' ? null : decision || (item.productCode ? policies.get(item.productCode) : null);
            const free = item.infrastructure || (!item.productCode && item.demo) || (!signedIn && policy?.mode === 'FREE');
            const state = { applicationId: item.id, allowed: free || decision?.allowed === true,
                reason: free ? 'FREE' : decision?.reason || (policy ? 'LOGIN_REQUIRED' : 'PRODUCT_UNAVAILABLE'),
                evaluatedAt: decision?.evaluatedAt || evaluatedAt, validUntil: decision?.validUntil || null };
            details.set(item.id, { applicationId: item.id, name: policy?.mode === null ? item.name : policy?.name || item.name,
                mode: policy?.mode || 'UNAVAILABLE', allowed: state.allowed, reason: message(state.reason),
                planName: state.reason === 'ADMINISTRATOR_DEVELOPMENT' ? '管理员开发使用（无需购买）' : decision?.subscription?.planName,
                accessKind: state.reason === 'ADMINISTRATOR_DEVELOPMENT' ? 'DEVELOPMENT' : undefined,
                startsAt: decision?.subscription?.startsAt,
                expiresAt: decision?.subscription?.expiresAt });
            return state;
        });
    }

    return {
        check,
        /** 主体和软件资料只返回公开摘要，不输出OAuth状态或凭据。 */
        snapshot() {
            const software = available().filter(item => !item.infrastructure && !item.demo).map(item => {
                const state = details.get(item.id);
                return state ? { ...state } : { applicationId: item.id, name: item.name, mode: 'UNAVAILABLE',
                    allowed: false, reason: '请刷新软件资料后查看使用状态' };
            });
            return { identity: identity ? { ...identity } : null, signOutPending: !!revoking, software };
        },
        /** 登录使用SDK的PKCE、nonce与签名验证，成功后再读取服务器名称。 */
        async signIn(signal) {
            if (disposed) throw Object.assign(new Error('账户会话已关闭'), { code: 'LOGIN_CANCELLED' });
            if (signOutTask) throw Object.assign(new Error('正在结束上次登录，请稍后重试'), { code: 'ACCOUNT_LOGOUT_PENDING' });
            if (revoking) throw Object.assign(new Error('请先重试完成原账户退出，再登录'), { code: 'REVOCATION_UNCONFIRMED' });
            if (identity && oidc) return;
            if (loginTask) return loginTask;
            const current = ++revision;
            loginController = new AbortController();
            const controller = loginController;
            const cancel = () => controller.abort();
            signal?.addEventListener('abort', cancel, { once: true });
            if (signal?.aborted) cancel();
            loginTask = (async () => {
                const { SccClient, SccOidcSession } = await clients();
                const next = await SccOidcSession.discover({ issuer: configuration.issuer, clientId: configuration.clientId,
                    redirectUri: configuration.redirectUri, postLogoutRedirectUri: configuration.postLogoutRedirectUri,
                    scope: 'openid profile api.read' + (configuration.requestDevelopmentAccess === true ? ' admin.read' : ''), allowLoopbackHttp: new URL(configuration.issuer).protocol === 'http:' });
                let accepted = false;
                try {
                if (disposed || controller.signal.aborted || revision !== current) throw Object.assign(new Error('登录已取消，可重新登录'), { code: 'LOGIN_CANCELLED' });
                const url = await next.beginLogin();
                const callback = await authorize({ url, issuer: configuration.issuer, redirectUri: configuration.redirectUri, signal: controller.signal });
                const summary = await next.completeLogin(callback);
                if (disposed || controller.signal.aborted || revision !== current) return;
                const business = new SccClient({ baseUrl: configuration.issuer, accessTokenProvider: () => next.accessToken(), maxRetries: 0 });
                const profile = await business.getCurrentUser();
                if (profile.subjectId !== summary.subject || disposed || controller.signal.aborted || revision !== current) throw Object.assign(new Error('账户已变化，请重新登录'), { code: 'ACCOUNT_CHANGED' });
                oidc = next; identity = { subject: profile.subjectId, displayName: profile.displayName };
                accepted = true; details.clear(); onChanged();
                } finally {
                    if (!accepted) {
                        const result = await next.logout();
                        retainCleanup(next, result); onChanged();
                    }
                }
            })();
            try { await loginTask; } finally { loginTask = undefined; loginController = undefined; signal?.removeEventListener('abort', cancel); }
        },
        /** 先使本机状态失效，再等待中心撤销和标准浏览器退出。 */
        async signOut() {
            if (signOutTask) return signOutTask;
            revision++; loginController?.abort(); identity = null; details.clear();
            const previous = oidc; oidc = null; onChanged();
            signOutTask = Promise.resolve().then(async () => {
                await loginTask?.catch(() => {});
                await cleanupTask?.catch(() => {});
                if (!previous && !revoking) return;
                const ending = revoking || { session: previous, result: null };
                revoking = ending;
                const retry = !!ending.result;
                const result = ending.result || await ending.session.logout();
                ending.result = result;
                const confirmed = result.revocationConfirmed || (retry && await ending.session.retryRevocation());
                if (!confirmed) throw Object.assign(new Error('本机已退出，请检查连接后重试中心撤销'), { code: 'REVOCATION_UNCONFIRMED' });
                const url = ending.session.beginLogout();
                if (url) {
                const callback = await authorize({ url, issuer: configuration.issuer,
                    redirectUri: configuration.postLogoutRedirectUri, title: '退出 CXX 账户' });
                ending.session.completeLogout(callback);
                }
                if (revoking === ending) revoking = null;
                onChanged();
            });
            try { await signOutTask; }
            catch (error) {
                if (error.code === 'REVOCATION_UNCONFIRMED') throw error;
                throw Object.assign(new Error('本机已退出，中心浏览器退出尚待确认，请重试退出'), { code: 'ACCOUNT_LOGOUT_PENDING' });
            } finally { signOutTask = null; }
        },
        /** 注册仅打开固定官网入口，不在宿主中复制账户和验证规则。 */
        openRegistration() {
            if (disposed) throw Object.assign(new Error('账户会话已关闭，请重新打开登录入口'), { code: 'ACCOUNT_CLOSED' });
            return openStore(new URL('/register', configuration.websiteOrigin).href);
        },
        /** 商城路由只接受已登记软件，不能由页面传入任意URL。 */
        openStore(id) {
            if (disposed) throw Object.assign(new Error('账户会话已关闭，请重新打开个人中心'), { code: 'ACCOUNT_CLOSED' });
            const entry = id === undefined ? null : available().find(item => item.id === id);
            if (id !== undefined && !entry?.productCode) throw Object.assign(new Error('请先在应用中心核对软件登记'), { code: 'APPLICATION_UNKNOWN' });
            return openStore(new URL(entry ? '/store/' + encodeURIComponent(entry.productCode) : '/store', configuration.websiteOrigin).href);
        },
        async destroy() {
            if (disposed) return;
            disposed = true; revision++; loginController?.abort(); identity = null; details.clear();
            const previous = oidc; oidc = null;
            await loginTask?.catch(() => {});
            await cleanupTask?.catch(() => {});
            await signOutTask?.catch(() => {});
            if (previous) retainCleanup(previous, await previous.logout());
            if (revoking && !await revoking.session.retryRevocation()) throw Object.assign(new Error('关闭前的中心撤销尚未确认，请在账户会话管理中核对'), { code: 'REVOCATION_UNCONFIRMED' });
        },
    };
}

/** 业务状态给出解决路径，不展示HTTP或OAuth内部错误。 */
function message(reason) {
    const messages = { FREE: '免费使用', ALLOWED: '当前可用', ADMINISTRATOR_DEVELOPMENT: '管理员开发资格，未上架、未定价或订阅到期不影响开发；实际操作由中心核验', LOGIN_REQUIRED: '登录后查看订阅或继续使用',
        PRODUCT_UNAVAILABLE: '软件资料尚未发布，请联系软件维护者核对登记', CLIENT_NOT_AUTHORIZED: '此软件接入配置尚未完成，请联系软件维护者核对授权绑定；其他软件不受影响', NO_SUBSCRIPTION: '尚未订阅，可查看软件介绍和套餐',
        OUTSIDE_ACCESS_PERIOD: '当前没有生效的使用周期，可核对到期时间或续费', SUBSCRIPTION_NOT_ACTIVE: '订阅当前未生效，可在个人中心核对',
        USER_NOT_ACTIVE: '账户当前不可用，请联系维护者核对账户状态', ACCOUNT_NOT_ACTIVE: '个人账户当前不可用，请联系维护者核对' };
    return messages[reason] || '使用资格暂未核对，请刷新或检查连接';
}

