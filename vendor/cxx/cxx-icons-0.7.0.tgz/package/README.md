# @cxx/icons

独立于 Vue、桌面外壳和项目模块的 SVG 资源包。源资产仍在 cxx-ui 仓库 icons/，原来的官网和图标预览路径不变。

```ts
import settings from '@cxx/icons/assets/01-settings.svg';
import settingsHover from '@cxx/icons/assets/01-settings-hover.svg';
import { iconUrl, iconNames } from '@cxx/icons';
const active = iconUrl('01-settings.svg', 'active');
```

静态 import 更适合按需打包；完整目录 URL API 可能把全量资源纳入构建。保留 default、hover、active、disabled 四状态，以及 assets/file-types/file-icon-map.json 映射。

资产许可 UNLICENSED，正式发布权限由维护者配置。

资源分类保持独立：`assets/NN-name.svg` 是标准操作图标，`assets/file-types/file-{type}.svg` 是文件扩展名图标。扩展名映射只维护 `assets/file-types/file-icon-map.json` 的 `extMap`。应用主图标属于仓库 `official/app/`，不混入这两类资源。文档「图标总览」分别检索两类图标，默认每页 3 组，支持每页 3 / 10 / 20 / 50 / 100 / 200 / 500、四态并排、名称校验、复制 SVG / PNG 和放大预览。
